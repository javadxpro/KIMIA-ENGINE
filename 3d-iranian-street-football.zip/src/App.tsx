import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
} from "react";
import { Game } from "./game/Game";
import { initialUI, type UIState } from "./game/types";

function fmtTime(s: number) {
  if (s > 9000) return "∞";
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${r.toString().padStart(2, "0")}`;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [ui, setUI] = useState<UIState>(initialUI());
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [ready, setReady] = useState(false);
  const joyRef = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const joyId = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new Game(canvas, setUI);
    gameRef.current = game;
    setReady(true);
    const unlock = () => {
      void gameRef.current;
    };
    window.addEventListener("pointerdown", unlock, { once: true });
    return () => {
      window.removeEventListener("pointerdown", unlock);
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  const play = () => {
    setSettingsOpen(false);
    void gameRef.current?.play();
  };
  const train = () => {
    setSettingsOpen(false);
    void gameRef.current?.train();
  };

  const onJoyStart = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    joyId.current = e.pointerId;
  }, []);

  const onJoyMove = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    if (joyId.current !== e.pointerId) return;
    const el = joyRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    let x = (e.clientX - cx) / (r.width * 0.42);
    let y = (e.clientY - cy) / (r.height * 0.42);
    const l = Math.hypot(x, y);
    if (l > 1) {
      x /= l;
      y /= l;
    }
    setKnob({ x, y });
    gameRef.current?.getInput().setJoystick(x, y);
  }, []);

  const onJoyEnd = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    if (joyId.current !== e.pointerId) return;
    joyId.current = null;
    setKnob({ x: 0, y: 0 });
    gameRef.current?.getInput().setJoystick(0, 0);
  }, []);

  const hold = (action: "shoot" | "pass" | "tackle" | "sprint") => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      gameRef.current?.getInput().setAction(action, true);
    },
    onPointerUp: () => gameRef.current?.getInput().setAction(action, false),
    onPointerCancel: () => gameRef.current?.getInput().setAction(action, false),
  });

  const inGame = ui.mode === "playing" || ui.mode === "training";
  const overlayMenu = ui.mode === "menu" || settingsOpen;

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-[#1a1210] text-stone-100">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {!ready && (
        <div className="absolute inset-0 z-50 grid place-items-center bg-[#1a1210]">
          <p className="text-lg text-amber-200/80">در حال ورود به محله...</p>
        </div>
      )}

      {overlayMenu && ui.mode === "menu" && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-between bg-gradient-to-b from-[#1a1210]/55 via-[#1a1210]/25 to-[#1a1210]/70 px-5 py-8">
          <div className="menu-enter mt-6 text-center">
            <p className="mb-2 text-[12px] tracking-[0.35em] text-amber-200/70">
              فوتبال خیابونی ایران
            </p>
            <h1
              className="text-5xl font-black leading-none text-[#f3e2b0] drop-shadow-[0_4px_0_rgba(90,30,16,0.55)] sm:text-6xl"
              style={{ textShadow: "0 2px 0 #6b1f14, 0 18px 40px rgba(0,0,0,0.45)" }}
            >
              کوی ابوذر
            </h1>
            <p className="mt-3 text-sm text-orange-100/70">
              غروب یک کوچه، یک توپ پلاستیکی، یک بازی بی‌پایان
            </p>
          </div>

          <div className="menu-enter flex w-full max-w-sm flex-col gap-3">
            <button
              onClick={play}
              className="rounded-2xl bg-gradient-to-l from-emerald-700 to-emerald-500 py-3.5 text-xl font-extrabold text-white shadow-[0_8px_0_#14532d] active:translate-y-1 active:shadow-none"
            >
              بازی ۳ به ۳
            </button>
            <button
              onClick={train}
              className="rounded-2xl bg-gradient-to-l from-amber-800 to-amber-600 py-3.5 text-xl font-extrabold text-white shadow-[0_8px_0_#7c4a12] active:translate-y-1 active:shadow-none"
            >
              تمرین
            </button>
            <button
              onClick={() => setSettingsOpen(true)}
              className="rounded-2xl bg-stone-800/80 py-3 text-lg font-bold text-amber-100 ring-1 ring-white/10"
            >
              تنظیمات
            </button>
          </div>

          <p className="text-center text-[11px] text-stone-300/70">
            WASD حرکت · Shift دویدن · Space شوت · E پاس · Q تکل · موس چرخش دوربین
          </p>
        </div>
      )}

      {settingsOpen && (
        <div className="absolute inset-0 z-30 grid place-items-center bg-black/55 p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#2a1e18]/95 p-6 ring-1 ring-amber-200/20">
            <h2 className="mb-5 text-center text-2xl font-black text-amber-100">تنظیمات</h2>
            <label className="mb-2 block text-sm text-stone-300">کیفیت تصویر</label>
            <div className="mb-5 grid grid-cols-3 gap-2">
              {(["low", "medium", "high"] as const).map((q) => (
                <button
                  key={q}
                  onClick={() => gameRef.current?.setQuality(q)}
                  className={`rounded-xl py-2 text-sm font-bold ${
                    ui.quality === q ? "bg-amber-600 text-white" : "bg-stone-800 text-stone-300"
                  }`}
                >
                  {q === "low" ? "کم" : q === "medium" ? "متوسط" : "زیاد"}
                </button>
              ))}
            </div>
            <div className="mb-4 flex items-center justify-between">
              <span>افکت صدا</span>
              <button
                onClick={() => gameRef.current?.setSfx(!ui.sfx)}
                className={`rounded-full px-4 py-1 text-sm font-bold ${ui.sfx ? "bg-emerald-600" : "bg-stone-700"}`}
              >
                {ui.sfx ? "روشن" : "خاموش"}
              </button>
            </div>
            <div className="mb-4 flex items-center justify-between">
              <span>موسیقی</span>
              <button
                onClick={() => gameRef.current?.setMusic(!ui.music)}
                className={`rounded-full px-4 py-1 text-sm font-bold ${ui.music ? "bg-emerald-600" : "bg-stone-700"}`}
              >
                {ui.music ? "روشن" : "خاموش"}
              </button>
            </div>
            <label className="mb-2 block text-sm text-stone-300">
              حساسیت دوربین ({ui.sensitivity.toFixed(1)})
            </label>
            <input
              type="range"
              min={0.4}
              max={2}
              step={0.1}
              value={ui.sensitivity}
              onChange={(e) => gameRef.current?.setSensitivity(Number(e.target.value))}
              className="mb-6 w-full accent-amber-500"
            />
            <button
              onClick={() => setSettingsOpen(false)}
              className="w-full rounded-xl bg-amber-700 py-3 font-bold"
            >
              بازگشت
            </button>
          </div>
        </div>
      )}

      {inGame && (
        <>
          <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex flex-col items-center pt-3">
            <div className="flex items-center gap-3 rounded-2xl bg-[#1a1210]/70 px-4 py-2 backdrop-blur-sm ring-1 ring-white/10">
              <div className="min-w-24 text-left text-sm font-bold text-emerald-300">{ui.teamA}</div>
              <div className="rounded-lg bg-black/40 px-3 py-1 font-black text-2xl tracking-widest text-amber-100">
                {ui.scoreA} <span className="text-stone-500">-</span> {ui.scoreB}
              </div>
              <div className="min-w-24 text-right text-sm font-bold text-red-300">{ui.teamB}</div>
            </div>
            <div className="mt-1 rounded-full bg-black/50 px-3 py-0.5 font-mono text-sm text-amber-200">
              {ui.mode === "training" ? "تمرین" : fmtTime(ui.timeLeft)}
            </div>
          </div>

          <button
            className="absolute top-3 left-3 z-20 rounded-xl bg-black/50 px-3 py-2 text-sm font-bold ring-1 ring-white/10"
            onClick={() => gameRef.current?.pause()}
          >
            توقف
          </button>

          {ui.mode === "training" && (
            <div className="pointer-events-none absolute top-20 right-3 z-10 max-w-[220px] rounded-xl bg-black/45 p-3 text-xs leading-6 text-amber-100/90">
              شوت، پاس و دریبل را آزاد تمرین کن.
              <br />
              R توپ را برمی‌گرداند.
              <br />
              محله را هم می‌توانی بگردی.
            </div>
          )}

          {ui.charging && (
            <div className="pointer-events-none absolute bottom-36 left-1/2 z-10 h-36 w-4 -translate-x-1/2 overflow-hidden rounded-full bg-black/50 ring-1 ring-white/20">
              <div
                className="power-fill absolute bottom-0 w-full rounded-full bg-gradient-to-t from-amber-300 to-red-500"
                style={{ height: `${Math.round(ui.shotPower * 100)}%` }}
              />
            </div>
          )}

          {ui.banner && (
            <div className="pointer-events-none absolute inset-0 z-20 grid place-items-center">
              <div className="goal-banner rounded-3xl bg-[#6b1f14]/85 px-10 py-5 text-4xl font-black text-amber-100 ring-2 ring-amber-200/40">
                {ui.banner}
              </div>
            </div>
          )}
        </>
      )}

      {ui.mode === "paused" && (
        <div className="absolute inset-0 z-30 grid place-items-center bg-black/55 p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#2a1e18] p-6 text-center">
            <h2 className="mb-5 text-2xl font-black text-amber-100">توقف بازی</h2>
            <button
              onClick={() => gameRef.current?.resume()}
              className="mb-3 w-full rounded-xl bg-emerald-600 py-3 font-bold"
            >
              ادامه
            </button>
            <button
              onClick={() => setSettingsOpen(true)}
              className="mb-3 w-full rounded-xl bg-stone-700 py-3 font-bold"
            >
              تنظیمات
            </button>
            <button
              onClick={() => gameRef.current?.toMenu()}
              className="w-full rounded-xl bg-red-800/80 py-3 font-bold"
            >
              منوی اصلی
            </button>
          </div>
        </div>
      )}

      {ui.mode === "result" && (
        <div className="absolute inset-0 z-30 grid place-items-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#2a1e18]/95 p-8 text-center ring-1 ring-amber-200/20">
            <p className="text-sm text-amber-200/70">پایان مسابقه</p>
            <h2 className="mt-2 text-3xl font-black text-amber-100">{ui.banner || "تمام"}</h2>
            <p className="mt-4 text-4xl font-black">
              {ui.scoreA} <span className="text-stone-500">-</span> {ui.scoreB}
            </p>
            <div className="mt-8 flex flex-col gap-3">
              <button onClick={play} className="rounded-xl bg-emerald-600 py-3 font-bold">
                بازی دوباره
              </button>
              <button
                onClick={() => gameRef.current?.toMenu()}
                className="rounded-xl bg-stone-700 py-3 font-bold"
              >
                منوی اصلی
              </button>
            </div>
          </div>
        </div>
      )}

      {ui.showMobile && inGame && (
        <div className="absolute inset-0 z-20 pointer-events-none">
          <div
            ref={joyRef}
            className="pointer-events-auto absolute bottom-8 left-6 h-36 w-36 rounded-full bg-black/30 ring-2 ring-white/25"
            onPointerDown={onJoyStart}
            onPointerMove={onJoyMove}
            onPointerUp={onJoyEnd}
            onPointerCancel={onJoyEnd}
          >
            <div
              className="absolute left-1/2 top-1/2 h-14 w-14 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/80 shadow-lg"
              style={{
                transform: `translate(calc(-50% + ${knob.x * 42}px), calc(-50% + ${knob.y * 42}px))`,
              }}
            />
          </div>

          <div className="pointer-events-auto absolute bottom-8 right-4 flex flex-col items-end gap-3">
            <div className="flex gap-3">
              <ActionBtn label="تکل" sub="Q" {...hold("tackle")} color="bg-stone-700" />
              <ActionBtn label="پاس" sub="E" {...hold("pass")} color="bg-sky-700" />
            </div>
            <div className="flex gap-3">
              <ActionBtn label="دویدن" sub="Shift" {...hold("sprint")} color="bg-amber-700" />
              <ActionBtn label="شوت" sub="Space" {...hold("shoot")} color="bg-emerald-600" big />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ActionBtn({
  label,
  sub,
  color,
  big,
  ...rest
}: {
  label: string;
  sub: string;
  color: string;
  big?: boolean;
} & ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      data-ui="btn"
      className={`${color} ${big ? "h-20 w-20 text-base" : "h-16 w-16 text-sm"} rounded-full font-black text-white shadow-lg ring-2 ring-white/20 active:scale-95`}
      {...rest}
    >
      {label}
      <span className="mt-0.5 block text-[9px] font-medium opacity-70">{sub}</span>
    </button>
  );
}
