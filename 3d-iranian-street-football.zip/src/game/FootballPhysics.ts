import type { BallEntity, Collider, Pitch, PlayerEntity } from "./types";
import { clamp, length2 } from "./math";

const GRAVITY = 22;
const RESTITUTION = 0.58;
const GROUND_FRICTION = 5.2;
const AIR_DRAG = 0.55;
const MAX_SPEED = 32;
const SPIN_FRICTION = 4.2;

export class FootballPhysics {
  colliders: Collider[] = [];
  pitch!: Pitch;

  setWorld(colliders: Collider[], pitch: Pitch) {
    this.colliders = colliders;
    this.pitch = pitch;
  }

  stepBall(ball: BallEntity, dt: number) {
    if (ball.ownerId >= 0) return;

    ball.velocity.y -= GRAVITY * dt;
    ball.velocity.x *= 1 - AIR_DRAG * dt;
    ball.velocity.z *= 1 - AIR_DRAG * dt;

    const sp = ball.velocity.length();
    if (sp > MAX_SPEED) ball.velocity.multiplyScalar(MAX_SPEED / sp);

    ball.position.x += ball.velocity.x * dt;
    ball.position.y += ball.velocity.y * dt;
    ball.position.z += ball.velocity.z * dt;

    let bounced = 0;
    if (ball.position.y <= ball.radius) {
      ball.position.y = ball.radius;
      if (ball.velocity.y < 0) {
        bounced = Math.abs(ball.velocity.y);
        ball.velocity.y *= -RESTITUTION;
        if (Math.abs(ball.velocity.y) < 1.2) ball.velocity.y = 0;
        const f = Math.exp(-GROUND_FRICTION * dt);
        ball.velocity.x *= f;
        ball.velocity.z *= f;
      }
      ball.onGround = true;
    } else {
      ball.onGround = false;
    }

    bounced = Math.max(bounced, this.collideBallWorld(ball));

    ball.position.x = clamp(ball.position.x, -50, 50);
    ball.position.z = clamp(ball.position.z, -44, 44);

    ball.angular.x += ball.velocity.z * dt * 3.2;
    ball.angular.z -= ball.velocity.x * dt * 3.2;
    ball.angular.multiplyScalar(Math.exp(-SPIN_FRICTION * dt * 0.15));
    ball.spinMesh.rotation.x = ball.angular.x;
    ball.spinMesh.rotation.z = ball.angular.z;
    ball.spinMesh.rotation.y += dt * 0.4 + ball.velocity.length() * dt * 0.08;

    return bounced;
  }

  collideBallWorld(ball: BallEntity) {
    let impact = 0;
    const r = ball.radius;
    for (const c of this.colliders) {
      const px = clamp(ball.position.x, c.minX, c.maxX);
      const py = clamp(ball.position.y, c.minY, c.maxY);
      const pz = clamp(ball.position.z, c.minZ, c.maxZ);
      const dx = ball.position.x - px;
      const dy = ball.position.y - py;
      const dz = ball.position.z - pz;
      const d2 = dx * dx + dy * dy + dz * dz;
      if (d2 >= r * r || d2 < 1e-8) continue;
      const d = Math.sqrt(d2);
      const nx = dx / d;
      const ny = dy / d;
      const nz = dz / d;
      const pen = r - d;
      ball.position.x += nx * pen;
      ball.position.y += ny * pen;
      ball.position.z += nz * pen;
      const vn = ball.velocity.x * nx + ball.velocity.y * ny + ball.velocity.z * nz;
      if (vn < 0) {
        const b = c.bounce;
        ball.velocity.x -= (1 + b) * vn * nx;
        ball.velocity.y -= (1 + b) * vn * ny;
        ball.velocity.z -= (1 + b) * vn * nz;
        impact = Math.max(impact, -vn);
      }
    }
    return impact;
  }

  collidePlayerWorld(p: PlayerEntity, dt: number) {
    p.position.x += p.velocity.x * dt;
    p.position.z += p.velocity.z * dt;
    p.position.y = 0;
    const r = p.radius;
    for (const c of this.colliders) {
      if (c.kind === "low") continue;
      if (c.maxY < 0.4) continue;
      const px = clamp(p.position.x, c.minX, c.maxX);
      const pz = clamp(p.position.z, c.minZ, c.maxZ);
      const dx = p.position.x - px;
      const dz = p.position.z - pz;
      const d2 = dx * dx + dz * dz;
      if (d2 < r * r && d2 > 1e-8) {
        const d = Math.sqrt(d2);
        const pen = r - d;
        p.position.x += (dx / d) * pen;
        p.position.z += (dz / d) * pen;
        p.velocity.x += (dx / d) * 2;
        p.velocity.z += (dz / d) * 2;
      } else if (d2 <= 1e-8) {
        const cx = (c.minX + c.maxX) * 0.5;
        const cz = (c.minZ + c.maxZ) * 0.5;
        const ox = p.position.x - cx;
        const oz = p.position.z - cz;
        if (Math.abs(ox) > Math.abs(oz))
          p.position.x = ox > 0 ? c.maxX + r : c.minX - r;
        else p.position.z = oz > 0 ? c.maxZ + r : c.minZ - r;
      }
    }
    p.position.x = clamp(p.position.x, -48, 48);
    p.position.z = clamp(p.position.z, -42, 42);
  }

  collidePlayers(players: PlayerEntity[]) {
    for (let i = 0; i < players.length; i++) {
      for (let j = i + 1; j < players.length; j++) {
        const a = players[i];
        const b = players[j];
        const dx = b.position.x - a.position.x;
        const dz = b.position.z - a.position.z;
        const d = Math.hypot(dx, dz) || 0.0001;
        const min = a.radius + b.radius - 0.02;
        if (d < min) {
          const pen = (min - d) * 0.5;
          const nx = dx / d;
          const nz = dz / d;
          a.position.x -= nx * pen;
          a.position.z -= nz * pen;
          b.position.x += nx * pen;
          b.position.z += nz * pen;
        }
      }
    }
  }

  dribble(player: PlayerEntity, ball: BallEntity, dt: number) {
    const facingX = Math.sin(player.yaw);
    const facingZ = Math.cos(player.yaw);
    const spd = length2(player.velocity.x, player.velocity.z);
    const ahead = 0.62 + Math.min(0.28, spd * 0.04);
    const tx = player.position.x + facingX * ahead;
    const tz = player.position.z + facingZ * ahead;
    const ty = ball.radius + Math.sin(player.animPhase * 2) * 0.02;
    ball.position.x += (tx - ball.position.x) * Math.min(1, dt * 14);
    ball.position.z += (tz - ball.position.z) * Math.min(1, dt * 14);
    ball.position.y += (ty - ball.position.y) * Math.min(1, dt * 10);
    ball.velocity.x = player.velocity.x * 0.92;
    ball.velocity.z = player.velocity.z * 0.92;
    ball.velocity.y = 0;
    ball.onGround = true;
    ball.ownerId = player.id;
    player.hasBall = true;
    ball.lastOwnerId = player.id;
    ball.lastTouchAt = 0;
    player.controlStick = Math.min(1, player.controlStick + dt * 2);
  }

  tryControl(player: PlayerEntity, ball: BallEntity) {
    if (player.stunTimer > 0 || player.tackleTimer > 0.05) return false;
    if (ball.position.y > 1.15) return false;
    const dx = ball.position.x - player.position.x;
    const dz = ball.position.z - player.position.z;
    const d = Math.hypot(dx, dz);
    const reach = player.radius + ball.radius + 0.55 + player.controlStick * 0.12;
    if (d > reach) return false;
    if (ball.ownerId >= 0 && ball.ownerId !== player.id) {
      if (d > 0.72) return false;
    }
    return true;
  }

  kick(
    player: PlayerEntity,
    ball: BallEntity,
    power: number,
    lift: number,
    dirX: number,
    dirZ: number,
  ) {
    const l = Math.hypot(dirX, dirZ) || 1;
    dirX /= l;
    dirZ /= l;
    const p = clamp(power, 0.15, 1);
    const spd = 9 + p * 18;
    ball.ownerId = -1;
    player.hasBall = false;
    ball.position.x = player.position.x + dirX * 0.7;
    ball.position.z = player.position.z + dirZ * 0.7;
    ball.position.y = ball.radius + lift * 0.25;
    ball.velocity.set(
      dirX * spd + player.velocity.x * 0.25,
      lift * (3.2 + p * 8.5),
      dirZ * spd + player.velocity.z * 0.25,
    );
    ball.lastOwnerId = player.id;
    ball.lastTouchAt = 0;
    player.controlStick = 0;
  }

  checkGoal(ball: BallEntity, pitch: Pitch): 0 | 1 | null {
    const gw = pitch.goalWidth * 0.5;
    const insideZ = Math.abs(ball.position.z) <= gw;
    const insideY = ball.position.y < pitch.goalHeight - 0.05;
    if (!insideZ || !insideY) return null;
    if (ball.position.x > pitch.maxX && ball.position.x < pitch.maxX + pitch.goalDepth + 0.6)
      return 0;
    if (ball.position.x < pitch.minX && ball.position.x > pitch.minX - pitch.goalDepth - 0.6)
      return 1;
    return null;
  }
}
