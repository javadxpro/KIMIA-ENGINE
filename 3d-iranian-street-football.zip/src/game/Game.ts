import * as THREE from "three";
import type { GameMode, GameSettings, Quality, UIState } from "./types";
import { TEAM_A_NAME, TEAM_B_NAME, initialUI } from "./types";
import { createTextures } from "./textures";
import { AudioManager } from "./AudioManager";
import { InputManager } from "./InputManager";
import { CameraController } from "./CameraController";
import { FootballPhysics } from "./FootballPhysics";
import { EnvironmentManager } from "./EnvironmentManager";
import { PlayerController } from "./PlayerController";
import { BallController } from "./BallController";
import { AIController } from "./AIController";
import { TeamManager } from "./TeamManager";
import { MatchManager } from "./MatchManager";
import { clamp } from "./math";

export class Game {
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();
  private raf = 0;
  private disposed = false;

  private input: InputManager;
  private audio = new AudioManager();
  private camCtrl: CameraController;
  private physics = new FootballPhysics();
  private env!: EnvironmentManager;
  private playersCtrl = new PlayerController();
  private ballCtrl!: BallController;
  private ai = new AIController();
  private teams = new TeamManager();
  private match = new MatchManager();

  private mode: GameMode = "menu";
  private settings: GameSettings;
  private onUI: (s: UIState) => void;
  private lastUI = "";
  private time = 0;
  private showMobile = false;

  constructor(canvas: HTMLCanvasElement, onUI: (s: UIState) => void) {
    this.onUI = onUI;
    this.settings = this.loadSettings();
    this.showMobile =
      "ontouchstart" in window || navigator.maxTouchPoints > 0 || window.innerWidth < 820;

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: this.settings.quality !== "low",
      powerPreference: "high-performance",
      alpha: false,
    });
    this.renderer.setPixelRatio(
      this.settings.quality === "low"
        ? 1
        : this.settings.quality === "medium"
          ? Math.min(1.4, window.devicePixelRatio)
          : Math.min(2, window.devicePixelRatio),
    );
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.02;
    this.renderer.shadowMap.enabled = this.settings.quality !== "low";
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setClearColor(0xc47a52, 1);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(
      58,
      window.innerWidth / Math.max(1, window.innerHeight),
      0.12,
      220,
    );
    this.camera.position.set(16, 9, 18);

    this.input = new InputManager(canvas);
    this.input.sensitivity = this.settings.sensitivity;
    this.camCtrl = new CameraController(this.camera);

    const tex = createTextures();
    this.env = new EnvironmentManager(this.scene, tex, this.settings.quality);
    this.physics.setWorld(this.env.colliders, this.env.pitch);
    this.teams.spawn(this.scene);
    this.ballCtrl = new BallController(this.scene, tex);

    this.audio.setSfx(this.settings.sfx);
    this.audio.setMusic(this.settings.music);

    window.addEventListener("resize", this.onResize);
    this.emitUI();
    this.clock.start();
    this.loop();
  }

  private loadSettings(): GameSettings {
    try {
      const raw = localStorage.getItem("abuzar-settings");
      if (raw) {
        const s = JSON.parse(raw) as GameSettings;
        return {
          quality: s.quality ?? "medium",
          sfx: s.sfx !== false,
          music: s.music !== false,
          sensitivity: s.sensitivity ?? 1,
        };
      }
    } catch {
      /* ignore */
    }
    return { quality: "medium", sfx: true, music: true, sensitivity: 1 };
  }

  private saveSettings() {
    localStorage.setItem("abuzar-settings", JSON.stringify(this.settings));
  }

  setQuality(q: Quality) {
    this.settings.quality = q;
    this.saveSettings();
    this.env.applyQuality(q, this.renderer);
    this.renderer.shadowMap.enabled = q !== "low";
    this.emitUI();
  }

  setSfx(on: boolean) {
    this.settings.sfx = on;
    this.audio.setSfx(on);
    this.saveSettings();
    this.emitUI();
  }

  setMusic(on: boolean) {
    this.settings.music = on;
    this.audio.setMusic(on);
    this.saveSettings();
    this.emitUI();
  }

  setSensitivity(v: number) {
    this.settings.sensitivity = v;
    this.input.sensitivity = v;
    this.saveSettings();
    this.emitUI();
  }

  async play() {
    await this.audio.resume();
    this.mode = "playing";
    this.teams.showAll();
    this.teams.resetKickoff(null);
    this.ballCtrl.reset(0, 0);
    this.match.startMatch();
    this.camCtrl.snapToPlayer(this.teams.human());
    void this.renderer.domElement.requestPointerLock();
    this.emitUI();
  }

  async train() {
    await this.audio.resume();
    this.mode = "training";
    this.teams.setTraining();
    this.ballCtrl.reset(-1, 0);
    this.match.startTraining();
    this.camCtrl.snapToPlayer(this.teams.human());
    void this.renderer.domElement.requestPointerLock();
    this.emitUI();
  }

  pause() {
    if (this.mode === "playing" || this.mode === "training") {
      this.mode = "paused";
      this.emitUI();
    }
  }

  resume() {
    if (this.mode === "paused") {
      this.mode = this.match.training ? "training" : "playing";
      this.emitUI();
    }
  }

  toMenu() {
    this.mode = "menu";
    this.match.running = false;
    this.match.over = false;
    this.camCtrl.mode = "cinematic";
    this.teams.showAll();
    this.teams.resetKickoff(null);
    this.ballCtrl.reset(0, 0);
    if (document.pointerLockElement) document.exitPointerLock();
    this.emitUI();
  }

  getInput() {
    return this.input;
  }

  private onResize = () => {
    const w = window.innerWidth;
    const h = Math.max(1, window.innerHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  };

  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, this.clock.getDelta());
    this.time += dt;
    this.update(dt);
    this.renderer.render(this.scene, this.camera);
  };

  private update(dt: number) {
    this.input.preUpdate();
    this.env.update(dt, this.time);

    if (this.input.pausePressed && (this.mode === "playing" || this.mode === "training")) {
      this.pause();
    } else if (this.input.pausePressed && this.mode === "paused") {
      this.resume();
    }

    if (this.mode === "menu" || this.mode === "result") {
      this.camCtrl.mode = this.mode === "result" ? this.camCtrl.mode : "cinematic";
      this.camCtrl.update(dt, null, 0, 0);
      this.idlePlayers(dt);
      this.ballCtrl.update(dt, this.teams.players, this.physics, this.audio);
      this.input.postUpdate();
      this.emitUI();
      return;
    }

    if (this.mode === "paused") {
      this.input.postUpdate();
      this.emitUI();
      return;
    }

    const human = this.teams.human();
    const live = this.match.freeze <= 0 && !this.match.over;

    if (live) {
      this.playersCtrl.updateHuman(human, this.input, this.camCtrl, dt);
      this.ai.update(
        this.teams.players,
        this.ballCtrl.ball,
        this.env.pitch,
        dt,
        this.time,
        this.playersCtrl,
        this.mode === "playing",
      );
      if (this.mode === "training") this.trainingHelpers();
    } else {
      for (const p of this.teams.players) p.intended.set(0, 0, 0);
    }

    if (live) this.handleActions();

    for (const p of this.teams.players) {
      if (!p.mesh.visible) continue;
      this.playersCtrl.tickMotion(p, dt, this.physics);
      if (this.mode === "playing") {
        const pitch = this.env.pitch;
        p.position.x = clamp(p.position.x, pitch.minX - 1.15, pitch.maxX + 1.15);
        p.position.z = clamp(p.position.z, pitch.minZ + 0.55, pitch.maxZ - 0.55);
        p.mesh.position.copy(p.position);
      }
    }
    this.physics.collidePlayers(this.teams.players.filter((p) => p.mesh.visible));
    this.ballCtrl.update(dt, this.teams.players.filter((p) => p.mesh.visible), this.physics, this.audio);

    if (this.mode === "playing" && this.match.freeze <= 0) {
      const pitch = this.env.pitch;
      const b = this.ballCtrl.ball;
      if (
        b.position.x < pitch.minX - 2.4 ||
        b.position.x > pitch.maxX + 2.4 ||
        b.position.z < pitch.minZ - 1.4 ||
        b.position.z > pitch.maxZ + 1.4
      ) {
        b.position.x = clamp(b.position.x, pitch.minX + 0.6, pitch.maxX - 0.6);
        b.position.z = clamp(b.position.z, pitch.minZ + 0.6, pitch.maxZ - 0.6);
        b.velocity.x *= 0.2;
        b.velocity.z *= 0.2;
        b.ownerId = -1;
        b.mesh.position.copy(b.position);
      }
    }

    this.match.update(
      dt,
      this.ballCtrl.ball,
      this.physics,
      this.env.pitch,
      this.audio,
      this.camCtrl,
    );

    if (this.match.pendingReset <= 0 && this.match.resetAttacker !== null) {
      this.teams.resetKickoff(this.match.resetAttacker);
      this.ballCtrl.reset(0, 0);
      this.match.resetAttacker = null;
    }

    if (this.match.over && this.mode === "playing") {
      this.mode = "result";
    }

    if (this.mode === "training" && this.input.resetPressed) {
      this.ballCtrl.reset(human.position.x + Math.sin(human.yaw) * 1.2, human.position.z + Math.cos(human.yaw) * 1.2);
    }

    const spd = Math.hypot(human.velocity.x, human.velocity.z);
    this.audio.footstep(dt, spd);

    this.camCtrl.update(dt, human, this.input.lookX, this.input.lookY);
    this.input.postUpdate();
    this.emitUI();
  }

  private idlePlayers(dt: number) {
    for (const p of this.teams.players) {
      p.intended.set(0, 0, 0);
      p.animPhase += dt * 2.2;
      p.mesh.position.copy(p.position);
      p.mesh.rotation.y = p.yaw;
    }
  }

  private handleActions() {
    const human = this.teams.human();
    const ball = this.ballCtrl.ball;
    const shot = this.playersCtrl.consumeShot();
    if (shot !== null) {
      const pwr = clamp(shot, 0.18, 1);
      if (this.canStrike(human, 1.35)) {
        this.playersCtrl.startKick(human);
        const aim = this.aimDir(human, pwr > 0.55);
        this.physics.kick(human, ball, pwr, pwr > 0.42 ? pwr : 0.08, aim.x, aim.z);
        this.audio.kick(pwr);
      }
    }
    if (this.input.passPressed && this.canStrike(human, 1.5)) {
      this.playersCtrl.startPass(human);
      const mate = this.bestMate(human);
      let dx = Math.sin(human.yaw);
      let dz = Math.cos(human.yaw);
      let pwr = 0.34;
      if (mate) {
        dx = mate.position.x - human.position.x;
        dz = mate.position.z - human.position.z;
        const dist = Math.hypot(dx, dz);
        pwr = clamp(dist / 13, 0.28, 0.72);
      }
      this.physics.kick(human, ball, pwr, 0.06, dx, dz);
      this.audio.pass();
    }
    if (this.input.tacklePressed) {
      this.playersCtrl.startTackle(human);
      this.audio.tackle();
    }

    for (const p of this.teams.players) {
      if (p.isHuman) continue;
      const k = this.ai.takePendingKick(p);
      if (k && this.canStrike(p, 1.6)) {
        this.physics.kick(p, ball, k.pwr, k.lift, k.x, k.z);
        this.audio.kick(k.pwr);
      }
    }
  }

  private canStrike(p: typeof this.teams.players[0], reach: number) {
    const b = this.ballCtrl.ball;
    if (b.ownerId === p.id) return true;
    const d = Math.hypot(b.position.x - p.position.x, b.position.z - p.position.z);
    return d < reach && b.position.y < 1.3;
  }

  private aimDir(p: typeof this.teams.players[0], towardGoal: boolean) {
    let x = Math.sin(p.yaw);
    let z = Math.cos(p.yaw);
    if (towardGoal) {
      const goalX = p.team === 0 ? this.env.pitch.maxX : this.env.pitch.minX;
      const gx = goalX - p.position.x;
      const gz = 0 - p.position.z;
      const gl = Math.hypot(gx, gz) || 1;
      const nx = gx / gl;
      const nz = gz / gl;
      const dot = x * nx + z * nz;
      if (dot > 0.35) {
        x = x * 0.55 + nx * 0.45;
        z = z * 0.55 + nz * 0.45;
      }
    }
    return { x, z };
  }

  private bestMate(p: typeof this.teams.players[0]) {
    const fx = Math.sin(p.yaw);
    const fz = Math.cos(p.yaw);
    let best = null as typeof p | null;
    let bestScore = -999;
    for (const m of this.teams.players) {
      if (m.team !== p.team || m.id === p.id || !m.mesh.visible) continue;
      const dx = m.position.x - p.position.x;
      const dz = m.position.z - p.position.z;
      const d = Math.hypot(dx, dz);
      if (d < 1.6 || d > 16) continue;
      const dot = (dx * fx + dz * fz) / d;
      const score = dot * 6 + (16 - d) * 0.15;
      if (dot > 0.05 && score > bestScore) {
        bestScore = score;
        best = m;
      }
    }
    return best;
  }

  private trainingHelpers() {
    const human = this.teams.human();
    const ball = this.ballCtrl.ball;
    for (const p of this.teams.players) {
      if (p.isHuman || p.team !== 0) continue;
      p.intended.set(0, 0, 0);
      const dx = ball.position.x - p.position.x;
      const dz = ball.position.z - p.position.z;
      const d = Math.hypot(dx, dz);
      if (d < 6) {
        const [nx, nz] = [dx / (d || 1), dz / (d || 1)];
        p.intended.set(nx * 3.2, 0, nz * 3.2);
      }
      if (d < 1.3 && ball.ownerId !== p.id && this.time - p.lastKickAt > 0.8) {
        p.yaw = Math.atan2(human.position.x - p.position.x, human.position.z - p.position.z);
        this.playersCtrl.startPass(p);
        p.lastKickAt = this.time;
        const hx = human.position.x - p.position.x;
        const hz = human.position.z - p.position.z;
        this.physics.kick(p, ball, 0.42, 0.08, hx, hz);
        this.audio.pass();
      }
      p.stamina = 1;
    }
  }

  private emitUI() {
    const ui: UIState = {
      ...initialUI(),
      mode: this.mode,
      scoreA: this.match.scoreA,
      scoreB: this.match.scoreB,
      timeLeft: Math.max(0, this.match.timeLeft),
      shotPower: this.playersCtrl.charge,
      charging: this.playersCtrl.charging,
      message: this.match.bannerT > 0 ? this.match.banner : "",
      banner: this.match.bannerT > 0 ? this.match.banner : "",
      teamA: TEAM_A_NAME,
      teamB: TEAM_B_NAME,
      showMobile: this.showMobile,
      quality: this.settings.quality,
      sfx: this.settings.sfx,
      music: this.settings.music,
      sensitivity: this.settings.sensitivity,
      trainingTips: this.mode === "training",
      matchOver: this.match.over,
      winner: this.match.winner,
      paused: this.mode === "paused",
      goalsA: this.match.scoreA,
      goalsB: this.match.scoreB,
    };
    const key = `${ui.mode}|${ui.scoreA}|${ui.scoreB}|${Math.floor(ui.timeLeft)}|${Math.round(ui.shotPower * 12)}|${ui.banner}|${ui.charging}|${ui.quality}|${ui.sfx}|${ui.music}|${ui.sensitivity}|${ui.paused}|${ui.winner}`;
    if (key === this.lastUI) return;
    this.lastUI = key;
    this.onUI(ui);
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    this.input.dispose();
    this.audio.dispose();
    this.renderer.dispose();
  }
}
