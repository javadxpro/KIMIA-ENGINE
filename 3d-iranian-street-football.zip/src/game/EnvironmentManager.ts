import * as THREE from "three";
import type { Collider, NpcEntity, Pitch, Quality } from "./types";
import type { GameTextures } from "./textures";
import { makeSignTexture } from "./textures";
import { mulberry32 } from "./math";
import {
  animatePlayer,
  createBench,
  createBin,
  createCat,
  createCooler,
  createGoal,
  createMotorcycle,
  createPaykan,
  createPlayerModel,
  createPot,
  createTree,
  geo,
  mat,
} from "./models";

class Batch {
  mesh: THREE.InstancedMesh;
  i = 0;
  max: number;
  dummy = new THREE.Object3D();
  color = new THREE.Color();
  constructor(geo: THREE.BufferGeometry, material: THREE.Material, count: number) {
    this.max = count;
    this.mesh = new THREE.InstancedMesh(geo, material, count);
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = true;
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  }
  add(
    x: number,
    y: number,
    z: number,
    sx: number,
    sy: number,
    sz: number,
    ry = 0,
    color?: number,
  ) {
    if (this.i >= this.max) return;
    this.dummy.position.set(x, y, z);
    this.dummy.rotation.set(0, ry, 0);
    this.dummy.scale.set(sx, sy, sz);
    this.dummy.updateMatrix();
    this.mesh.setMatrixAt(this.i, this.dummy.matrix);
    if (color !== undefined) {
      this.color.setHex(color);
      this.mesh.setColorAt(this.i, this.color);
    }
    this.i++;
  }
  finalize(scene: THREE.Scene) {
    this.mesh.count = this.i;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
    scene.add(this.mesh);
  }
}

const PLASTER = [
  0xcbb396, 0xd4c4a8, 0xb8956e, 0xc9b8a0, 0xdaad86, 0xa89070, 0xd8cbb8, 0xc07050,
  0xb9a58c, 0x9c7e62, 0xcfc0a6, 0x8f6a52,
];
const DOORS = [0x1f5c56, 0x2d6b62, 0x3d5a80, 0x6b2d2d, 0x4a4a4a, 0x245c2e, 0x7a5a2a];

export class EnvironmentManager {
  scene: THREE.Scene;
  colliders: Collider[] = [];
  pitch: Pitch = {
    minX: -14.5,
    maxX: 14.5,
    minZ: -8.2,
    maxZ: 8.2,
    goalWidth: 3.2,
    goalHeight: 2.05,
    goalDepth: 1.15,
  };
  npcs: NpcEntity[] = [];
  movers: { mesh: THREE.Object3D; update: (t: number, dt: number) => void }[] = [];
  private sun!: THREE.DirectionalLight;
  private rng: () => number;
  private tex: GameTextures;
  private quality: Quality;
  clothes: THREE.Object3D[] = [];

  constructor(
    scene: THREE.Scene,
    tex: GameTextures,
    quality: Quality,
  ) {
    this.scene = scene;
    this.tex = tex;
    this.quality = quality;
    this.rng = mulberry32(14027);
    this.build();
  }

  private collider(
    x: number,
    z: number,
    w: number,
    d: number,
    h: number,
    bounce = 0.45,
    kind: Collider["kind"] = "building",
  ) {
    this.colliders.push({
      minX: x - w / 2,
      maxX: x + w / 2,
      minY: 0,
      maxY: h,
      minZ: z - d / 2,
      maxZ: z + d / 2,
      bounce,
      kind,
    });
  }

  private build() {
    this.lights();
    this.sky();
    this.ground();
    this.pitchMarkings();
    this.buildings();
    this.props();
    this.wires();
    this.people();
    this.fenceAndGoals();
  }

  private lights() {
    this.scene.fog = new THREE.Fog(0xc4845c, 28, this.quality === "low" ? 70 : 95);
    this.scene.background = new THREE.Color(0xc47a52);

    const hemi = new THREE.HemisphereLight(0xffb078, 0x6a4a38, 0.72);
    this.scene.add(hemi);

    this.sun = new THREE.DirectionalLight(0xffd0a0, 1.35);
    this.sun.position.set(-38, 26, 18);
    this.sun.castShadow = this.quality !== "low";
    const res = this.quality === "high" ? 2048 : this.quality === "medium" ? 1024 : 512;
    this.sun.shadow.mapSize.set(res, res);
    this.sun.shadow.camera.near = 2;
    this.sun.shadow.camera.far = 90;
    this.sun.shadow.camera.left = -40;
    this.sun.shadow.camera.right = 40;
    this.sun.shadow.camera.top = 30;
    this.sun.shadow.camera.bottom = -30;
    this.sun.shadow.bias = -0.0007;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);

    const fill = new THREE.DirectionalLight(0x8870aa, 0.18);
    fill.position.set(20, 12, -10);
    this.scene.add(fill);

    const shop = new THREE.PointLight(0xffaa55, 1.6, 12, 1.6);
    shop.position.set(6, 2.2, 14.2);
    if (this.quality !== "low") this.scene.add(shop);
  }

  private sky() {
    const skyMat = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec3 vP;
        void main(){
          vP = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0);
        }`,
      fragmentShader: `
        varying vec3 vP;
        void main(){
          float h = normalize(vP).y;
          vec3 horizon = vec3(1.0, 0.55, 0.28);
          vec3 mid = vec3(0.92, 0.42, 0.28);
          vec3 top = vec3(0.32, 0.22, 0.52);
          vec3 col = mix(horizon, mid, smoothstep(-0.05, 0.18, h));
          col = mix(col, top, smoothstep(0.18, 0.72, h));
          float sun = pow(max(dot(normalize(vP), normalize(vec3(-0.55,0.28,0.28))), 0.0), 48.0);
          col += vec3(1.0, 0.75, 0.35) * sun * 0.85;
          gl_FragColor = vec4(col, 1.0);
        }`,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      toneMapped: false,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(180, 24, 16), skyMat);
    this.scene.add(sky);

    const sunBall = new THREE.Mesh(
      new THREE.SphereGeometry(4.5, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0xffe2a0, fog: false }),
    );
    sunBall.position.set(-70, 28, 32);
    this.scene.add(sunBall);
  }

  private ground() {
    const asphaltM = new THREE.MeshLambertMaterial({
      map: this.tex.asphalt,
      color: 0x7a7a78,
    });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(110, 100), asphaltM);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);

    const pitchM = new THREE.MeshLambertMaterial({
      map: this.tex.asphalt,
      color: 0x6a6a66,
    });
    const pitch = new THREE.Mesh(new THREE.PlaneGeometry(30, 17.2), pitchM);
    pitch.rotation.x = -Math.PI / 2;
    pitch.position.y = 0.012;
    pitch.receiveShadow = true;
    this.scene.add(pitch);

    const walkM = new THREE.MeshLambertMaterial({ map: this.tex.sidewalk });
    const walkN = new THREE.Mesh(new THREE.PlaneGeometry(90, 3.2), walkM);
    walkN.rotation.x = -Math.PI / 2;
    walkN.position.set(0, 0.03, -10.4);
    walkN.receiveShadow = true;
    this.scene.add(walkN);
    const walkS = walkN.clone();
    walkS.position.set(0, 0.03, 10.6);
    this.scene.add(walkS);

    const dirtM = new THREE.MeshLambertMaterial({ map: this.tex.dirt, color: 0x8a754c });
    const gutter = new THREE.Mesh(new THREE.BoxGeometry(88, 0.12, 0.55), dirtM);
    gutter.position.set(0, -0.02, -8.85);
    this.scene.add(gutter);
    const gutter2 = gutter.clone();
    gutter2.position.z = 8.95;
    this.scene.add(gutter2);
    const water = new THREE.Mesh(
      new THREE.BoxGeometry(88, 0.02, 0.32),
      new THREE.MeshStandardMaterial({
        color: 0x3a5a48,
        roughness: 0.15,
        metalness: 0.2,
        transparent: true,
        opacity: 0.55,
      }),
    );
    water.position.set(0, 0.03, -8.85);
    this.scene.add(water);

    const curbM = new THREE.MeshLambertMaterial({ color: 0x9a958c });
    const curb1 = new THREE.Mesh(new THREE.BoxGeometry(88, 0.18, 0.22), curbM);
    curb1.position.set(0, 0.08, -8.55);
    curb1.receiveShadow = true;
    this.scene.add(curb1);
    const curb2 = curb1.clone();
    curb2.position.z = 8.65;
    this.scene.add(curb2);
  }

  private pitchMarkings() {
    const lineM = new THREE.MeshBasicMaterial({ color: 0xe8e4d8 });
    const line = (x: number, z: number, w: number, d: number) => {
      const m = new THREE.Mesh(geo.box, lineM);
      m.position.set(x, 0.025, z);
      m.scale.set(w, 0.02, d);
      this.scene.add(m);
    };
    const { minX, maxX, minZ, maxZ } = this.pitch;
    const w = maxX - minX;
    const d = maxZ - minZ;
    line(0, minZ, w, 0.08);
    line(0, maxZ, w, 0.08);
    line(minX, 0, 0.08, d);
    line(maxX, 0, 0.08, d);
    line(0, 0, 0.08, d);
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(2.35, 2.45, 32),
      lineM,
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.03;
    this.scene.add(ring);
    const spot = new THREE.Mesh(new THREE.CircleGeometry(0.16, 10), lineM);
    spot.rotation.x = -Math.PI / 2;
    spot.position.y = 0.03;
    this.scene.add(spot);
    line(minX + 3.2, 0, 0.08, 7);
    line(minX + 1.6, 3.5, 3.2, 0.08);
    line(minX + 1.6, -3.5, 3.2, 0.08);
    line(maxX - 3.2, 0, 0.08, 7);
    line(maxX - 1.6, 3.5, 3.2, 0.08);
    line(maxX - 1.6, -3.5, 3.2, 0.08);

    const banner = makeSignTexture("زمین فوتبال کوی ابوذر", "#5a1e16", "#f2e2b0", 768, 180);
    const sign = new THREE.Mesh(
      new THREE.PlaneGeometry(6.4, 1.5),
      new THREE.MeshLambertMaterial({ map: banner }),
    );
    sign.position.set(0, 3.6, -12.6);
    this.scene.add(sign);
    const poleL = new THREE.Mesh(geo.cyl, mat(0x555555));
    poleL.position.set(-3.1, 1.8, -12.55);
    poleL.scale.set(0.08, 3.6, 0.08);
    this.scene.add(poleL);
    const poleR = poleL.clone();
    poleR.position.x = 3.1;
    this.scene.add(poleR);
  }

  private fenceAndGoals() {
    const goalA = createGoal(this.tex.net, 1);
    goalA.rotation.y = Math.PI / 2;
    goalA.position.set(this.pitch.maxX, 0, 0);
    this.scene.add(goalA);
    const goalB = createGoal(this.tex.net, 1);
    goalB.rotation.y = -Math.PI / 2;
    goalB.position.set(this.pitch.minX, 0, 0);
    this.scene.add(goalB);

    const barM = new THREE.MeshLambertMaterial({ map: this.tex.metal, color: 0x8a9094 });
    const bars = new Batch(geo.box, barM, 280);
    const addFence = (x0: number, z0: number, x1: number, z1: number) => {
      const dx = x1 - x0;
      const dz = z1 - z0;
      const len = Math.hypot(dx, dz);
      const n = Math.floor(len / 0.28);
      const ry = Math.atan2(dx, dz);
      for (let i = 0; i <= n; i++) {
        const t = i / n;
        bars.add(x0 + dx * t, 0.55, z0 + dz * t, 0.04, 1.1, 0.04, ry, 0x7a8084);
      }
    };
    addFence(this.pitch.minX - 0.4, this.pitch.minZ - 0.35, this.pitch.maxX + 0.4, this.pitch.minZ - 0.35);
    addFence(this.pitch.minX - 0.4, this.pitch.maxZ + 0.35, this.pitch.maxX + 0.4, this.pitch.maxZ + 0.35);
    addFence(this.pitch.minX - 0.4, this.pitch.minZ - 0.35, this.pitch.minX - 0.4, -1.65);
    addFence(this.pitch.minX - 0.4, 1.65, this.pitch.minX - 0.4, this.pitch.maxZ + 0.35);
    addFence(this.pitch.maxX + 0.4, this.pitch.minZ - 0.35, this.pitch.maxX + 0.4, -1.65);
    addFence(this.pitch.maxX + 0.4, 1.65, this.pitch.maxX + 0.4, this.pitch.maxZ + 0.35);
    bars.finalize(this.scene);

    const railM = mat(0x667078);
    const rail1 = new THREE.Mesh(geo.box, railM);
    rail1.position.set(0, 1.12, this.pitch.minZ - 0.35);
    rail1.scale.set(this.pitch.maxX - this.pitch.minX + 0.8, 0.05, 0.05);
    this.scene.add(rail1);
    const rail2 = rail1.clone();
    rail2.position.z = this.pitch.maxZ + 0.35;
    this.scene.add(rail2);

    this.collider(0, this.pitch.minZ - 0.35, 30, 0.2, 1.2, 0.62, "fence");
    this.collider(0, this.pitch.maxZ + 0.35, 30, 0.2, 1.2, 0.62, "fence");
    this.collider(this.pitch.minX - 0.4, -5.1, 0.2, 6.4, 1.2, 0.62, "fence");
    this.collider(this.pitch.minX - 0.4, 5.1, 0.2, 6.4, 1.2, 0.62, "fence");
    this.collider(this.pitch.maxX + 0.4, -5.1, 0.2, 6.4, 1.2, 0.62, "fence");
    this.collider(this.pitch.maxX + 0.4, 5.1, 0.2, 6.4, 1.2, 0.62, "fence");

    this.collider(this.pitch.maxX + 0.55, -2.4, 0.18, 1.6, 2.05, 0.35, "fence");
    this.collider(this.pitch.maxX + 0.55, 2.4, 0.18, 1.6, 2.05, 0.35, "fence");
    this.collider(this.pitch.maxX + 1.1, 0, 0.12, 3.2, 2.05, 0.2, "fence");
    this.collider(this.pitch.minX - 0.55, -2.4, 0.18, 1.6, 2.05, 0.35, "fence");
    this.collider(this.pitch.minX - 0.55, 2.4, 0.18, 1.6, 2.05, 0.35, "fence");
    this.collider(this.pitch.minX - 1.1, 0, 0.12, 3.2, 2.05, 0.2, "fence");
  }

  private buildings() {
    const plasterM = new THREE.MeshLambertMaterial({
      map: this.tex.plaster,
      color: 0xffffff,
    });
    const brickM = new THREE.MeshLambertMaterial({
      map: this.tex.brick,
      color: 0xffffff,
    });
    const bodies = new Batch(geo.box, plasterM, 90);
    const bricks = new Batch(geo.box, brickM, 40);
    const winLitM = new THREE.MeshLambertMaterial({
      map: this.tex.windowLit,
      color: 0xffffff,
    });
    const winDarkM = new THREE.MeshLambertMaterial({
      map: this.tex.windowDark,
      color: 0xffffff,
    });
    const winsLit = new Batch(geo.box, winLitM, 420);
    const winsDark = new Batch(geo.box, winDarkM, 420);
    const doorM = new THREE.MeshStandardMaterial({
      map: this.tex.metal,
      color: 0xffffff,
      metalness: 0.45,
      roughness: 0.45,
    });
    const doors = new Batch(geo.box, doorM, 70);
    const parapetM = new THREE.MeshLambertMaterial({ color: 0xb8a48a });
    const parapets = new Batch(geo.box, parapetM, 160);


    const addWindows = (
      x: number,
      z: number,
      w: number,
      d: number,
      floors: number,
      ry: number,
    ) => {
      const fx = Math.sin(ry);
      const fz = Math.cos(ry);
      for (let f = 0; f < floors; f++) {
        const wy = 1.15 + f * 2.55;
        const cols = Math.max(2, Math.floor(w / 1.7));
        for (let c = 0; c < cols; c++) {
          const along = -w / 2 + 0.8 + (c * (w - 1.6)) / Math.max(1, cols - 1);
          const px = x + fx * (d / 2 + 0.04) + Math.cos(ry) * along;
          const pz = z + fz * (d / 2 + 0.04) + Math.sin(ry) * along;
          const lit = this.rng() > 0.55;
          const batch = lit ? winsLit : winsDark;
          batch.add(px, wy, pz, 0.7, 0.9, 0.08, ry);
        }
      }
    };

    const building = (
      x: number,
      z: number,
      w: number,
      d: number,
      floors: number,
      brick: boolean,
      ry = 0,
      shop?: string,
    ) => {
      const h = floors * 2.55 + 0.8;
      const col = PLASTER[Math.floor(this.rng() * PLASTER.length)];
      const batch = brick ? bricks : bodies;
      batch.add(x, h / 2, z, w, h, d, ry, brick ? 0xffffff : col);
      this.collider(x, z, w * 0.98, d * 0.98, h, 0.42, "building");
      addWindows(x, z, w, d, floors, ry);
      if (Math.abs(ry) < 0.1 || Math.abs(Math.abs(ry) - Math.PI) < 0.1) {
        addWindows(x, z, w, d, floors, ry + Math.PI);
      }
      const doorCol = DOORS[Math.floor(this.rng() * DOORS.length)];
      const fx = Math.sin(ry);
      const fz = Math.cos(ry);
      doors.add(
        x + fx * (d / 2 + 0.03),
        1.05,
        z + fz * (d / 2 + 0.03),
        0.95,
        2.1,
        0.08,
        ry,
        doorCol,
      );
      parapets.add(x, h + 0.16, z - d / 2 + 0.08, w, 0.32, 0.12, ry, col);
      parapets.add(x, h + 0.16, z + d / 2 - 0.08, w, 0.32, 0.12, ry, col);
      parapets.add(x - w / 2 + 0.08, h + 0.16, z, 0.12, 0.32, d, ry, col);
      parapets.add(x + w / 2 - 0.08, h + 0.16, z, 0.12, 0.32, d, ry, col);

      if (this.rng() > 0.35) {
        const ac = createCooler();
        ac.position.set(x + (this.rng() - 0.5) * w * 0.4, h, z + (this.rng() - 0.5) * d * 0.3);
        ac.scale.setScalar(0.9 + this.rng() * 0.3);
        this.scene.add(ac);
      }
      if (this.rng() > 0.4) {
        const tank = new THREE.Mesh(geo.cyl, mat(0xb0b8bc));
        tank.position.set(x + w * 0.25, h + 0.55, z - d * 0.15);
        tank.scale.set(0.7, 1.1, 0.7);
        tank.castShadow = true;
        this.scene.add(tank);
      }
      if (this.rng() > 0.5) {
        const dish = new THREE.Mesh(
          new THREE.CircleGeometry(0.35, 10),
          mat(0xcfd4d8),
        );
        dish.position.set(x - w * 0.2, h + 0.7, z);
        dish.rotation.x = -0.9;
        this.scene.add(dish);
      }
      if (shop) {
        const tex = makeSignTexture(shop, "#6b1f14", "#f3e2b0", 512, 160);
        const s = new THREE.Mesh(
          new THREE.PlaneGeometry(Math.min(w * 0.8, 3.6), 0.7),
          new THREE.MeshLambertMaterial({ map: tex }),
        );
        s.position.set(
          x + fx * (d / 2 + 0.08),
          2.55,
          z + fz * (d / 2 + 0.08),
        );
        s.rotation.y = ry;
        this.scene.add(s);
        const canopy = new THREE.Mesh(geo.box, mat(0x7a2a22));
        canopy.position.set(
          x + fx * (d / 2 + 0.45),
          2.15,
          z + fz * (d / 2 + 0.45),
        );
        canopy.scale.set(Math.min(w * 0.9, 4.2), 0.06, 0.9);
        canopy.rotation.y = ry;
        canopy.castShadow = true;
        this.scene.add(canopy);
      }
    };

    const northZ = -14.6;
    const southZ = 15.2;
    const north: { x: number; w: number; d: number; f: number; brick: boolean; shop?: string }[] = [
      { x: -34, w: 8, d: 7.2, f: 2, brick: true },
      { x: -25, w: 7.4, d: 6.8, f: 3, brick: false },
      { x: -17, w: 6.8, d: 7.5, f: 2, brick: true },
      { x: -9.2, w: 7.2, d: 6.6, f: 4, brick: false },
      { x: -1.2, w: 6.5, d: 7, f: 3, brick: true },
      { x: 6.6, w: 7.4, d: 6.8, f: 2, brick: false },
      { x: 14.5, w: 6.6, d: 7.2, f: 3, brick: true },
      { x: 22.2, w: 7, d: 6.5, f: 2, brick: false },
      { x: 30.5, w: 8, d: 7.4, f: 3, brick: true },
    ];
    for (const b of north) {
      building(b.x, northZ, b.w, b.d, b.f, b.brick, Math.PI);
    }

    const south: typeof north = [
      { x: -33, w: 7.5, d: 7, f: 2, brick: false, shop: "آرایشگاه رضا" },
      { x: -24.5, w: 7.2, d: 7.4, f: 3, brick: true, shop: "بقالی حاجی" },
      { x: -16.2, w: 6.8, d: 6.8, f: 2, brick: false, shop: "نانوایی سنگک" },
      { x: -8.4, w: 7, d: 7.2, f: 3, brick: true },
      { x: -0.5, w: 6.6, d: 6.6, f: 2, brick: false, shop: "میوه و سبزی" },
      { x: 7.2, w: 7.4, d: 7.5, f: 3, brick: true, shop: "چایخانه ابوذر" },
      { x: 15.4, w: 6.8, d: 6.8, f: 2, brick: false },
      { x: 23.2, w: 7.2, d: 7.2, f: 4, brick: true },
      { x: 31.4, w: 7.6, d: 7, f: 2, brick: false, shop: "تعمیرات موتور" },
    ];
    for (const b of south) {
      building(b.x, southZ, b.w, b.d, b.f, b.brick, 0, b.shop);
    }

    building(-40.5, -2, 7.2, 10, 3, true, Math.PI / 2);
    building(-40.8, 10, 6.8, 8.5, 2, false, Math.PI / 2);
    building(-40.2, -14, 7, 8, 2, false, Math.PI / 2);
    building(40.2, -3, 7.4, 11, 3, false, -Math.PI / 2);
    building(40.5, 11, 6.6, 8, 2, true, -Math.PI / 2);
    building(40, -15, 7, 8.2, 4, true, -Math.PI / 2);

    building(-28, -24.5, 8, 7, 2, false, Math.PI);
    building(-18, -24.2, 7.2, 6.8, 3, true, Math.PI);
    building(-8, -24.6, 6.5, 7.2, 2, false, Math.PI);
    building(4, -24.3, 8, 7, 3, true, Math.PI);
    building(16, -24.8, 7, 6.6, 2, false, Math.PI);
    building(28, -24.4, 7.5, 7, 2, true, Math.PI);

    building(-20, 25.5, 8, 7, 2, true, 0);
    building(-8, 25.2, 7, 6.8, 3, false, 0);
    building(6, 25.6, 7.4, 7.2, 2, true, 0);
    building(18, 25.3, 8, 7, 2, false, 0);

    bodies.finalize(this.scene);
    bricks.finalize(this.scene);
    winsLit.finalize(this.scene);
    winsDark.finalize(this.scene);
    doors.finalize(this.scene);
    parapets.finalize(this.scene);

    this.clothesline(-21.2, -11.2, -21.2, -17.8);
    this.clothesline(10.4, -11.4, 10.4, -17.6);
    this.clothesline(-12.4, 11.8, -12.4, 18.4);

    const rug = new THREE.Mesh(
      new THREE.PlaneGeometry(1.4, 2.1),
      new THREE.MeshLambertMaterial({ map: this.tex.rug, side: THREE.DoubleSide }),
    );
    rug.position.set(-8.8, 1.6, -11.05);
    rug.rotation.x = -0.15;
    this.scene.add(rug);
    const rug2 = rug.clone();
    rug2.position.set(7.4, 1.5, 11.55);
    this.scene.add(rug2);
  }

  private clothesline(x1: number, z1: number, x2: number, z2: number) {
    const pts = [new THREE.Vector3(x1, 4.4, z1), new THREE.Vector3(x2, 4.3, z2)];
    const curve = new THREE.LineCurve3(pts[0], pts[1]);
    const tube = new THREE.Mesh(
      new THREE.TubeGeometry(curve, 4, 0.015, 4, false),
      mat(0x333333),
    );
    this.scene.add(tube);
    const colors = [0xe8e0d0, 0x3a5c8a, 0xa33a3a, 0xd8d8d8, 0x2d6b4a, 0xc47a2a];
    const n = 5;
    for (let i = 0; i < n; i++) {
      const t = 0.12 + (i / (n - 1)) * 0.76;
      const p = new THREE.Vector3().lerpVectors(pts[0], pts[1], t);
      const cloth = new THREE.Mesh(geo.box, mat(colors[i % colors.length]));
      cloth.position.copy(p);
      cloth.position.y -= 0.45;
      cloth.scale.set(0.08, 0.9, 0.55);
      this.scene.add(cloth);
      this.clothes.push(cloth);
    }
  }

  private wires() {
    const poleM = new THREE.MeshLambertMaterial({ color: 0x4a4038 });
    const poles: THREE.Vector3[] = [];
    const addPole = (x: number, z: number) => {
      const p = new THREE.Mesh(geo.cyl, poleM);
      p.position.set(x, 3.4, z);
      p.scale.set(0.16, 6.8, 0.16);
      p.castShadow = true;
      this.scene.add(p);
      const cross = new THREE.Mesh(geo.box, poleM);
      cross.position.set(x, 6.5, z);
      cross.scale.set(1.4, 0.08, 0.08);
      this.scene.add(cross);
      poles.push(new THREE.Vector3(x, 6.55, z));
      this.collider(x, z, 0.3, 0.3, 6.8, 0.2, "prop");
    };
    addPole(-16, -9.6);
    addPole(-2, -9.7);
    addPole(12, -9.55);
    addPole(26, -9.7);
    addPole(-16, 10.1);
    addPole(0, 10.15);
    addPole(14, 10.05);
    addPole(28, 10.2);
    addPole(-38, 0);
    addPole(38, 1);

    const wireM = new THREE.LineBasicMaterial({ color: 0x1a1a1a });
    for (let i = 0; i < poles.length - 1; i++) {
      if (Math.abs(poles[i].z - poles[i + 1].z) > 8) continue;
      const a = poles[i];
      const b = poles[i + 1];
      const mid = a.clone().lerp(b, 0.5);
      mid.y -= 0.55;
      const curve = new THREE.QuadraticBezierCurve3(a, mid, b);
      const pts = curve.getPoints(10);
      const g = new THREE.BufferGeometry().setFromPoints(pts);
      this.scene.add(new THREE.Line(g, wireM));
      const a2 = a.clone();
      a2.x += 0.35;
      const b2 = b.clone();
      b2.x += 0.35;
      const mid2 = a2.clone().lerp(b2, 0.5);
      mid2.y -= 0.4;
      const c2 = new THREE.QuadraticBezierCurve3(a2, mid2, b2);
      this.scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(c2.getPoints(10)), wireM));
    }

    const lampM = mat(0xffd090);
    for (const p of poles.slice(0, 6)) {
      const bulb = new THREE.Mesh(geo.sphere, lampM);
      bulb.position.set(p.x, 5.4, p.z + (p.z < 0 ? 0.5 : -0.5));
      bulb.scale.setScalar(0.18);
      this.scene.add(bulb);
    }
  }

  private props() {
    const rng = this.rng;
    for (let i = 0; i < 14; i++) {
      const t = createTree(rng);
      const side = i % 2 === 0 ? -1 : 1;
      const x = -32 + (i * 5.1) % 68;
      const z = side * (11.6 + rng() * 1.4);
      if (Math.abs(x) < 16 && Math.abs(z) < 10) continue;
      t.position.set(x, 0, z);
      this.scene.add(t);
      this.collider(x, z, 0.6, 0.6, 2, 0.15, "prop");
    }

    const bikes = [
      [-12.5, -9.1, 0.4],
      [4.2, 9.3, -0.2],
      [18.4, -9.0, 1.2],
      [-22.2, 9.4, 0.1],
      [9.6, 9.5, 3.1],
      [-6.4, -9.2, -0.5],
    ] as const;
    for (const b of bikes) {
      const m = createMotorcycle();
      m.position.set(b[0], 0, b[1]);
      m.rotation.y = b[2];
      this.scene.add(m);
      this.collider(b[0], b[1], 0.6, 1.1, 1.1, 0.2, "prop");
    }

    const car1 = createPaykan(0xb8b0a0);
    car1.position.set(-30.5, 0, 9.6);
    car1.rotation.y = 0.08;
    this.scene.add(car1);
    this.collider(-30.5, 9.6, 1.6, 3.5, 1.2, 0.25, "prop");

    const car2 = createPaykan(0x4a6b8a);
    car2.position.set(24.5, 0, -9.4);
    car2.rotation.y = Math.PI + 0.12;
    this.scene.add(car2);
    this.collider(24.5, -9.4, 1.6, 3.5, 1.2, 0.25, "prop");

    const car3 = createPaykan(0x6a2a28);
    car3.position.set(33, 0, 12.4);
    car3.rotation.y = -0.4;
    this.scene.add(car3);
    this.collider(33, 12.4, 1.6, 3.5, 1.2, 0.25, "prop");

    const bins = [
      [-14.8, -9.0],
      [11.2, 9.4],
      [2.4, -9.1],
      [-25, 9.5],
      [20.5, 9.3],
    ];
    for (const b of bins) {
      const bin = createBin();
      bin.position.set(b[0], 0, b[1]);
      this.scene.add(bin);
      this.collider(b[0], b[1], 0.4, 0.4, 0.9, 0.2, "low");
    }

    const benches = [
      [-7.5, -9.15, 0],
      [8.8, -9.15, 0],
      [1.2, 9.45, Math.PI],
    ];
    for (const b of benches) {
      const bench = createBench();
      bench.position.set(b[0], 0, b[1]);
      bench.rotation.y = b[2];
      this.scene.add(bench);
    }

    for (let i = 0; i < 18; i++) {
      const pot = createPot();
      const side = i % 2 === 0 ? -11.15 : 11.35;
      pot.position.set(-28 + i * 3.4, 0, side);
      if (Math.abs(pot.position.x) > 38) continue;
      this.scene.add(pot);
    }

    const cat = createCat();
    cat.position.set(-9.5, 2.55, -11.1);
    this.scene.add(cat);
    this.movers.push({
      mesh: cat,
      update: (t) => {
        cat.position.x = -9.5 + Math.sin(t * 0.3) * 0.4;
      },
    });

    const movingBike = createMotorcycle();
    this.scene.add(movingBike);
    this.movers.push({
      mesh: movingBike,
      update: (t) => {
        const u = (t * 0.12) % 1;
        const x = -42 + u * 84;
        movingBike.position.set(x, 0, 12.8);
        movingBike.rotation.y = Math.PI / 2;
      },
    });

    const movingBike2 = createMotorcycle();
    this.scene.add(movingBike2);
    this.movers.push({
      mesh: movingBike2,
      update: (t) => {
        const u = (t * 0.09 + 0.5) % 1;
        const x = 42 - u * 84;
        movingBike2.position.set(x, 0, -12.6);
        movingBike2.rotation.y = -Math.PI / 2;
      },
    });

    const coneM = mat(0xd45c1a);
    for (let i = 0; i < 4; i++) {
      const c = new THREE.Mesh(geo.cone, coneM);
      c.position.set(-13 + i * 0.7, 0.22, 7.4);
      c.scale.set(0.28, 0.45, 0.28);
      c.castShadow = true;
      this.scene.add(c);
    }

    const graffiti = makeSignTexture("کوی ابوذر", "#3a3a38", "#e8d48a", 512, 180);
    const wallArt = new THREE.Mesh(
      new THREE.PlaneGeometry(3.2, 1.1),
      new THREE.MeshLambertMaterial({ map: graffiti }),
    );
    wallArt.position.set(-16.6, 1.7, -11.05);
    wallArt.rotation.y = Math.PI;
    this.scene.add(wallArt);

    const plaque = makeSignTexture("بن‌بست شهید رجایی", "#d8d0c0", "#2a2a2a", 420, 140);
    const pl = new THREE.Mesh(
      new THREE.PlaneGeometry(2.2, 0.7),
      new THREE.MeshLambertMaterial({ map: plaque }),
    );
    pl.position.set(14.6, 2.4, -11.05);
    pl.rotation.y = Math.PI;
    this.scene.add(pl);
  }

  private people() {
    const skins = [0xc49a72, 0xb8885a, 0xd4ae86, 0xa87848];
    const hairs = [0x1a120c, 0x2a1a10, 0x3a2818, 0x111111];
    const shirts = [0x3a5c8a, 0x8a3a3a, 0xd8d0c4, 0x2d6b4a, 0x4a4a4a, 0xc47a2a];

    const mk = (
      kind: NpcEntity["kind"],
      x: number,
      z: number,
      path: THREE.Vector3[],
      speed: number,
    ) => {
      const vis = createPlayerModel({
        skin: skins[Math.floor(this.rng() * skins.length)],
        hair: hairs[Math.floor(this.rng() * hairs.length)],
        jersey: shirts[Math.floor(this.rng() * shirts.length)],
        shorts: kind === "kid" ? 0x3a3a6a : 0x3a3a3a,
        socks: 0xeeeeee,
        shoes: 0x222222,
      });
      if (kind === "kid") vis.group.scale.setScalar(0.72);
      vis.group.position.set(x, 0, z);
      this.scene.add(vis.group);
      const npc: NpcEntity = {
        mesh: vis.group,
        bones: vis.bones,
        path: path.length ? path : [new THREE.Vector3(x, 0, z)],
        seg: 0,
        t: 0,
        speed,
        yaw: 0,
        phase: this.rng() * 10,
        kind,
      };
      this.npcs.push(npc);
    };

    mk(
      "walker",
      -22,
      -10.5,
      [
        new THREE.Vector3(-22, 0, -10.5),
        new THREE.Vector3(8, 0, -10.5),
        new THREE.Vector3(20, 0, -10.6),
        new THREE.Vector3(-10, 0, -10.4),
      ],
      1.15,
    );
    mk(
      "walker",
      16,
      10.7,
      [
        new THREE.Vector3(16, 0, 10.7),
        new THREE.Vector3(-18, 0, 10.8),
        new THREE.Vector3(-30, 0, 10.6),
        new THREE.Vector3(4, 0, 10.7),
      ],
      1.05,
    );
    mk(
      "kid",
      -4.5,
      9.1,
      [new THREE.Vector3(-4.5, 0, 9.1)],
      0,
    );
    mk(
      "kid",
      -3.6,
      9.35,
      [new THREE.Vector3(-3.6, 0, 9.35)],
      0,
    );
    mk(
      "spectator",
      6.4,
      -9.05,
      [new THREE.Vector3(6.4, 0, -9.05)],
      0,
    );
    mk(
      "spectator",
      7.3,
      -9.15,
      [new THREE.Vector3(7.3, 0, -9.15)],
      0,
    );
    mk(
      "spectator",
      -10.2,
      9.2,
      [new THREE.Vector3(-10.2, 0, 9.2)],
      0,
    );
    mk(
      "shopkeeper",
      7.2,
      11.4,
      [new THREE.Vector3(7.2, 0, 11.4)],
      0,
    );
    mk(
      "walker",
      30,
      10.6,
      [
        new THREE.Vector3(30, 0, 10.6),
        new THREE.Vector3(30, 0, 22),
        new THREE.Vector3(18, 0, 22),
        new THREE.Vector3(18, 0, 10.8),
      ],
      1.0,
    );
    mk(
      "kid",
      12.5,
      9.2,
      [
        new THREE.Vector3(12.5, 0, 9.2),
        new THREE.Vector3(14.5, 0, 9.4),
        new THREE.Vector3(12.2, 0, 9.5),
      ],
      1.4,
    );
  }

  update(dt: number, time: number) {
    for (const m of this.movers) m.update(time, dt);
    for (const c of this.clothes) {
      c.rotation.y = Math.sin(time * 1.4 + c.position.x) * 0.2;
    }
    for (const npc of this.npcs) {
      npc.phase += dt * (npc.speed > 0.2 ? 6.5 : 1.4);
      if (npc.path.length > 1 && npc.speed > 0) {
        const a = npc.path[npc.seg];
        const b = npc.path[(npc.seg + 1) % npc.path.length];
        const dist = a.distanceTo(b) || 1;
        npc.t += (npc.speed * dt) / dist;
        if (npc.t >= 1) {
          npc.t = 0;
          npc.seg = (npc.seg + 1) % npc.path.length;
        }
        const p = a.clone().lerp(b, npc.t);
        npc.mesh.position.copy(p);
        npc.yaw = Math.atan2(b.x - a.x, b.z - a.z);
        npc.mesh.rotation.y = npc.yaw;
        animatePlayer(npc.bones, "walk", npc.phase, npc.speed, 0, 0);
      } else {
        if (npc.kind === "spectator") {
          npc.mesh.rotation.y = Math.atan2(-npc.mesh.position.x, -npc.mesh.position.z);
          npc.bones.torso.rotation.y = Math.sin(time * 0.6 + npc.phase) * 0.15;
        }
        animatePlayer(
          npc.bones,
          npc.kind === "kid" ? "idle" : "idle",
          npc.phase,
          0,
          0,
          0,
        );
      }
    }
  }

  applyQuality(q: Quality, renderer: THREE.WebGLRenderer) {
    this.quality = q;
    this.sun.castShadow = q !== "low";
    const res = q === "high" ? 2048 : q === "medium" ? 1024 : 512;
    this.sun.shadow.mapSize.set(res, res);
    renderer.shadowMap.enabled = q !== "low";
    const pr =
      q === "low" ? 1 : q === "medium" ? Math.min(1.5, window.devicePixelRatio) : Math.min(2, window.devicePixelRatio);
    renderer.setPixelRatio(pr);
    if (this.scene.fog && this.scene.fog instanceof THREE.Fog) {
      this.scene.fog.far = q === "low" ? 70 : 95;
    }
  }
}
