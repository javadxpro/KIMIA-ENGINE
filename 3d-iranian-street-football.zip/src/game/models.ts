import * as THREE from "three";
import type { PlayerBones } from "./types";

const geo = {
  box: new THREE.BoxGeometry(1, 1, 1),
  sphere: new THREE.SphereGeometry(0.5, 10, 8),
  cyl: new THREE.CylinderGeometry(0.5, 0.5, 1, 8),
  cyl6: new THREE.CylinderGeometry(0.5, 0.5, 1, 6),
  cone: new THREE.ConeGeometry(0.5, 1, 8),
};

function mat(color: number, opts?: THREE.MeshLambertMaterialParameters) {
  return new THREE.MeshLambertMaterial({ color, ...opts });
}

function add(
  parent: THREE.Object3D,
  geometry: THREE.BufferGeometry,
  material: THREE.Material,
  x: number,
  y: number,
  z: number,
  sx: number,
  sy: number,
  sz: number,
  cast = true,
) {
  const m = new THREE.Mesh(geometry, material);
  m.position.set(x, y, z);
  m.scale.set(sx, sy, sz);
  m.castShadow = cast;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

export interface PlayerVisual {
  group: THREE.Group;
  bones: PlayerBones;
}

export function createPlayerModel(opts: {
  skin: number;
  hair: number;
  jersey: number;
  stripe?: number;
  shorts: number;
  socks: number;
  shoes: number;
  number?: number;
}): PlayerVisual {
  const group = new THREE.Group();
  const skinM = mat(opts.skin);
  const hairM = mat(opts.hair);
  const jerseyM = mat(opts.jersey);
  const shortsM = mat(opts.shorts);
  const socksM = mat(opts.socks);
  const shoeM = mat(opts.shoes);
  const stripeM = mat(opts.stripe ?? 0xf2f2f2);

  const root = new THREE.Group();
  group.add(root);

  const torso = new THREE.Group();
  torso.position.y = 1.12;
  root.add(torso);
  add(torso, geo.box, jerseyM, 0, 0.08, 0, 0.42, 0.48, 0.26);
  add(torso, geo.box, stripeM, 0, 0.08, 0.13, 0.12, 0.48, 0.02, false);
  add(torso, geo.box, shortsM, 0, -0.32, 0, 0.4, 0.22, 0.24);
  if (opts.number !== undefined) {
    const c = document.createElement("canvas");
    c.width = 64;
    c.height = 64;
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#f4f0e4";
    ctx.font = "bold 42px Vazirmatn, Tahoma, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(opts.number), 32, 36);
    const ntex = new THREE.CanvasTexture(c);
    ntex.colorSpace = THREE.SRGBColorSpace;
    const nm = new THREE.Mesh(
      new THREE.PlaneGeometry(0.2, 0.22),
      new THREE.MeshLambertMaterial({ map: ntex, transparent: true }),
    );
    nm.position.set(0, 0.12, -0.14);
    nm.rotation.y = Math.PI;
    torso.add(nm);
    const nf = nm.clone();
    nf.position.z = 0.14;
    nf.rotation.y = 0;
    torso.add(nf);
  }

  const head = new THREE.Group();
  head.position.set(0, 0.46, 0);
  torso.add(head);
  add(head, geo.box, skinM, 0, 0.08, 0, 0.22, 0.24, 0.2);
  add(head, geo.box, hairM, 0, 0.18, -0.01, 0.23, 0.1, 0.22);
  const eyeM = mat(0x1a1a1a);
  add(head, geo.box, eyeM, -0.05, 0.1, 0.1, 0.04, 0.035, 0.03, false);
  add(head, geo.box, eyeM, 0.05, 0.1, 0.1, 0.04, 0.035, 0.03, false);

  const makeArm = (side: number) => {
    const arm = new THREE.Group();
    arm.position.set(0.26 * side, 0.18, 0);
    torso.add(arm);
    add(arm, geo.box, jerseyM, 0, -0.12, 0, 0.1, 0.28, 0.1);
    const fore = new THREE.Group();
    fore.position.set(0, -0.28, 0);
    arm.add(fore);
    add(fore, geo.box, skinM, 0, -0.12, 0, 0.09, 0.26, 0.09);
    return { arm, fore };
  };
  const L = makeArm(-1);
  const R = makeArm(1);

  const makeLeg = (side: number) => {
    const thigh = new THREE.Group();
    thigh.position.set(0.11 * side, 0.72, 0);
    root.add(thigh);
    add(thigh, geo.box, shortsM, 0, -0.16, 0, 0.14, 0.32, 0.16);
    const shin = new THREE.Group();
    shin.position.set(0, -0.34, 0);
    thigh.add(shin);
    add(shin, geo.box, socksM, 0, -0.16, 0, 0.12, 0.34, 0.14);
    add(shin, geo.box, shoeM, 0, -0.34, 0.06, 0.13, 0.08, 0.26);
    return { thigh, shin };
  };
  const LL = makeLeg(-1);
  const RL = makeLeg(1);

  const bones: PlayerBones = {
    root,
    torso,
    head,
    lArm: L.arm,
    rArm: R.arm,
    lFore: L.fore,
    rFore: R.fore,
    lThigh: LL.thigh,
    rThigh: RL.thigh,
    lShin: LL.shin,
    rShin: RL.shin,
  };
  return { group, bones };
}

export function animatePlayer(
  bones: PlayerBones,
  anim: string,
  phase: number,
  speed: number,
  kickT: number,
  tackleT: number,
) {
  const sp = Math.min(1.6, speed / 7);
  const swing = Math.sin(phase) * (0.55 + sp * 0.55);
  const idle = Math.sin(phase * 0.55) * 0.03;

  bones.root.position.y = 0;
  bones.torso.rotation.x = 0;
  bones.torso.rotation.y = 0;
  bones.torso.position.y = 1.12;
  bones.head.rotation.x = 0;

  if (kickT > 0) {
    const k = Math.sin((1 - Math.min(1, kickT / 0.32)) * Math.PI);
    bones.rThigh.rotation.x = -k * 1.35;
    bones.rShin.rotation.x = k * 0.5;
    bones.lThigh.rotation.x = 0.15;
    bones.torso.rotation.y = -k * 0.25;
    bones.rArm.rotation.x = k * 0.4;
    bones.lArm.rotation.x = -k * 0.5;
    return;
  }
  if (tackleT > 0) {
    const t = Math.min(1, tackleT / 0.35);
    bones.torso.rotation.x = 0.55;
    bones.root.position.y = 0.08;
    bones.lThigh.rotation.x = -0.7 * t;
    bones.rThigh.rotation.x = 0.9 * t;
    bones.lArm.rotation.x = -0.8;
    bones.rArm.rotation.x = 0.6;
    return;
  }

  bones.root.position.y = anim === "idle" ? idle * 0.4 : Math.abs(Math.sin(phase)) * 0.05 * sp;

  if (anim === "idle") {
    bones.lThigh.rotation.x = idle;
    bones.rThigh.rotation.x = -idle;
    bones.lShin.rotation.x = 0.08;
    bones.rShin.rotation.x = 0.08;
    bones.lArm.rotation.x = 0.15 + idle;
    bones.rArm.rotation.x = 0.15 - idle;
    bones.lFore.rotation.x = 0.2;
    bones.rFore.rotation.x = 0.2;
    return;
  }

  const lean = anim === "sprint" ? 0.28 : anim === "run" ? 0.16 : 0.06;
  bones.torso.rotation.x = lean;
  bones.head.rotation.x = -lean * 0.4;
  bones.lThigh.rotation.x = swing;
  bones.rThigh.rotation.x = -swing;
  bones.lShin.rotation.x = Math.max(0, -swing) * 0.7 + 0.1;
  bones.rShin.rotation.x = Math.max(0, swing) * 0.7 + 0.1;
  bones.lArm.rotation.x = -swing * 0.85;
  bones.rArm.rotation.x = swing * 0.85;
  bones.lFore.rotation.x = 0.45;
  bones.rFore.rotation.x = 0.45;
}

export function createBallModel(tex: THREE.Texture) {
  const g = new THREE.Group();
  const spin = new THREE.Group();
  const m = new THREE.Mesh(
    new THREE.SphereGeometry(0.11, 16, 12),
    new THREE.MeshStandardMaterial({
      map: tex,
      roughness: 0.42,
      metalness: 0.05,
    }),
  );
  m.castShadow = true;
  spin.add(m);
  g.add(spin);
  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(0.13, 10),
    new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.28,
      depthWrite: false,
    }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.015;
  g.add(shadow);
  return { group: g, spin, blob: shadow };
}

export function createGoal(netTex: THREE.Texture, facing: number) {
  const g = new THREE.Group();
  const metal = new THREE.MeshStandardMaterial({
    color: 0xd8dce0,
    metalness: 0.7,
    roughness: 0.3,
  });
  const post = (x: number, y: number, z: number, sx: number, sy: number, sz: number) => {
    const m = new THREE.Mesh(geo.box, metal);
    m.position.set(x, y, z);
    m.scale.set(sx, sy, sz);
    m.castShadow = true;
    g.add(m);
  };
  const w = 3.2;
  const h = 2.05;
  const d = 1.15;
  post(-w / 2, h / 2, 0, 0.08, h, 0.08);
  post(w / 2, h / 2, 0, 0.08, h, 0.08);
  post(0, h, 0, w, 0.08, 0.08);
  post(-w / 2, h / 2, -d * facing, 0.07, h, 0.07);
  post(w / 2, h / 2, -d * facing, 0.07, h, 0.07);
  post(0, h, -d * facing, w, 0.07, 0.07);
  post(-w / 2, 0.04, -d * 0.5 * facing, 0.07, 0.07, d);
  post(w / 2, 0.04, -d * 0.5 * facing, 0.07, 0.07, d);

  const netMat = new THREE.MeshBasicMaterial({
    map: netTex,
    transparent: true,
    opacity: 0.55,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const back = new THREE.Mesh(new THREE.PlaneGeometry(w, h), netMat);
  back.position.set(0, h / 2, -d * facing);
  g.add(back);
  const sideG = new THREE.PlaneGeometry(d, h);
  const s1 = new THREE.Mesh(sideG, netMat);
  s1.position.set(-w / 2, h / 2, (-d * facing) / 2);
  s1.rotation.y = Math.PI / 2;
  g.add(s1);
  const s2 = new THREE.Mesh(sideG, netMat);
  s2.position.set(w / 2, h / 2, (-d * facing) / 2);
  s2.rotation.y = Math.PI / 2;
  g.add(s2);
  return g;
}

export function createTree(rng: () => number) {
  const g = new THREE.Group();
  const trunk = new THREE.Mesh(
    geo.cyl,
    mat(0x5a3a22),
  );
  const h = 2.2 + rng() * 1.4;
  trunk.scale.set(0.18, h, 0.18);
  trunk.position.y = h / 2;
  trunk.castShadow = true;
  g.add(trunk);
  const foliageM = mat(0x2f5a28 + Math.floor(rng() * 10) * 0x010100);
  for (let i = 0; i < 4; i++) {
    const s = new THREE.Mesh(geo.sphere, foliageM);
    const r = 1.1 + rng() * 0.7;
    s.scale.set(r * 1.1, r * 0.85, r * 1.1);
    s.position.set((rng() - 0.5) * 0.6, h * 0.75 + rng() * 0.5, (rng() - 0.5) * 0.6);
    s.castShadow = true;
    g.add(s);
  }
  return g;
}

export function createMotorcycle() {
  const g = new THREE.Group();
  const body = mat(0xc45c26);
  const dark = mat(0x1a1a1a);
  const chrome = new THREE.MeshStandardMaterial({
    color: 0xaaaaaa,
    metalness: 0.8,
    roughness: 0.3,
  });
  add(g, geo.box, body, 0, 0.55, 0, 0.28, 0.18, 1.05);
  add(g, geo.box, dark, 0, 0.72, -0.12, 0.22, 0.14, 0.35);
  const wheel = (z: number) => {
    const w = new THREE.Mesh(geo.cyl, dark);
    w.rotation.z = Math.PI / 2;
    w.scale.set(0.38, 0.12, 0.38);
    w.position.set(0, 0.28, z);
    g.add(w);
    const rim = new THREE.Mesh(geo.cyl, chrome);
    rim.rotation.z = Math.PI / 2;
    rim.scale.set(0.18, 0.13, 0.18);
    rim.position.set(0, 0.28, z);
    g.add(rim);
  };
  wheel(0.38);
  wheel(-0.38);
  add(g, geo.box, dark, 0, 0.95, 0.32, 0.08, 0.45, 0.08);
  add(g, geo.box, dark, 0, 1.12, 0.4, 0.32, 0.05, 0.08);
  return g;
}

export function createPaykan(color: number) {
  const g = new THREE.Group();
  const body = mat(color);
  const dark = mat(0x161616);
  const glass = new THREE.MeshLambertMaterial({
    color: 0x88aacc,
    transparent: true,
    opacity: 0.55,
  });
  add(g, geo.box, body, 0, 0.42, 0, 1.55, 0.42, 3.4);
  add(g, geo.box, body, 0, 0.85, -0.15, 1.45, 0.48, 1.7);
  add(g, geo.box, glass, 0, 0.88, 0.55, 1.3, 0.32, 0.08, false);
  add(g, geo.box, glass, 0, 0.88, -0.95, 1.3, 0.32, 0.08, false);
  add(g, geo.box, dark, 0.78, 0.28, 1.05, 0.22, 0.42, 0.42);
  add(g, geo.box, dark, -0.78, 0.28, 1.05, 0.22, 0.42, 0.42);
  add(g, geo.box, dark, 0.78, 0.28, -1.1, 0.22, 0.42, 0.42);
  add(g, geo.box, dark, -0.78, 0.28, -1.1, 0.22, 0.42, 0.42);
  const lightM = mat(0xffe9a0);
  add(g, geo.box, lightM, 0.45, 0.42, 1.72, 0.22, 0.12, 0.06, false);
  add(g, geo.box, lightM, -0.45, 0.42, 1.72, 0.22, 0.12, 0.06, false);
  return g;
}

export function createCooler() {
  const g = new THREE.Group();
  const m = mat(0xc8d0d4);
  add(g, geo.box, m, 0, 0.35, 0, 0.85, 0.7, 0.7);
  add(g, geo.cyl, mat(0x9aa2a6), 0, 0.78, 0, 0.55, 0.12, 0.55);
  add(g, geo.box, mat(0x6a7380), 0, 0.38, 0.36, 0.6, 0.4, 0.04, false);
  return g;
}

export function createBin() {
  const g = new THREE.Group();
  add(g, geo.cyl, mat(0x2f6b3a), 0, 0.38, 0, 0.32, 0.76, 0.32);
  add(g, geo.cyl, mat(0x1e1e1e), 0, 0.78, 0, 0.34, 0.06, 0.34);
  return g;
}

export function createBench() {
  const g = new THREE.Group();
  const wood = mat(0x6b4a2a);
  const iron = mat(0x333333);
  add(g, geo.box, wood, 0, 0.42, 0, 1.4, 0.07, 0.38);
  add(g, geo.box, wood, 0, 0.72, -0.16, 1.4, 0.32, 0.07);
  add(g, geo.box, iron, -0.55, 0.22, 0, 0.07, 0.44, 0.34);
  add(g, geo.box, iron, 0.55, 0.22, 0, 0.07, 0.44, 0.34);
  return g;
}

export function createPot() {
  const g = new THREE.Group();
  add(g, geo.cyl, mat(0x8a3a2a), 0, 0.12, 0, 0.18, 0.24, 0.18);
  add(g, geo.sphere, mat(0x2e6b32), 0, 0.32, 0, 0.28, 0.22, 0.28);
  return g;
}

export function createCat() {
  const g = new THREE.Group();
  const fur = mat(0xc8c2b4);
  add(g, geo.box, fur, 0, 0.12, 0, 0.16, 0.12, 0.32);
  add(g, geo.box, fur, 0, 0.18, 0.18, 0.12, 0.12, 0.12);
  add(g, geo.box, mat(0x222), 0, 0.1, -0.2, 0.04, 0.04, 0.12);
  return g;
}

export { geo, mat, add };
