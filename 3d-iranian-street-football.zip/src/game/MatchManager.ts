import { MATCH_GOAL_LIMIT, MATCH_SECONDS } from "./types";
import type { BallEntity, Pitch } from "./types";
import type { FootballPhysics } from "./FootballPhysics";
import type { AudioManager } from "./AudioManager";
import type { CameraController } from "./CameraController";

export class MatchManager {
  scoreA = 0;
  scoreB = 0;
  timeLeft = MATCH_SECONDS;
  running = false;
  freeze = 0;
  banner = "";
  bannerT = 0;
  over = false;
  winner: 0 | 1 | 2 = 2;
  training = false;
  justScored: 0 | 1 | null = null;
  pendingReset = 0;
  resetAttacker: 0 | 1 | null = null;
  pendingEnd = 0;

  startMatch() {
    this.scoreA = 0;
    this.scoreB = 0;
    this.timeLeft = MATCH_SECONDS;
    this.running = true;
    this.over = false;
    this.winner = 2;
    this.training = false;
    this.freeze = 2.4;
    this.banner = "آماده شوید";
    this.bannerT = 2.4;
    this.justScored = null;
    this.pendingReset = 0;
    this.pendingEnd = 0;
  }

  startTraining() {
    this.training = true;
    this.running = true;
    this.over = false;
    this.freeze = 0;
    this.banner = "حالت تمرین";
    this.bannerT = 1.8;
    this.scoreA = 0;
    this.scoreB = 0;
    this.timeLeft = 9999;
    this.pendingReset = 0;
    this.pendingEnd = 0;
  }

  update(
    dt: number,
    ball: BallEntity,
    physics: FootballPhysics,
    pitch: Pitch,
    audio: AudioManager,
    cam: CameraController,
  ) {
    this.justScored = null;
    if (this.bannerT > 0) this.bannerT -= dt;
    if (this.pendingEnd > 0) {
      this.pendingEnd -= dt;
      if (this.pendingEnd <= 0) this.end(audio);
    }
    if (this.pendingReset > 0) {
      this.pendingReset -= dt;
    }
    if (this.freeze > 0) {
      this.freeze -= dt;
      if (this.freeze <= 0 && !this.over && !this.training) {
        audio.whistle();
        this.banner = "شروع!";
        this.bannerT = 0.7;
      }
      return;
    }
    if (!this.running || this.over) return;

    if (!this.training) {
      this.timeLeft -= dt;
      if (this.timeLeft <= 0) {
        this.timeLeft = 0;
        this.end(audio);
        return;
      }
    }

    const g = physics.checkGoal(ball, pitch);
    if (g === 0 || g === 1) {
      if (g === 0) this.scoreA += 1;
      else this.scoreB += 1;
      this.justScored = g;
      audio.cheer();
      audio.whistle();
      this.banner = "گل!";
      this.bannerT = 1.8;
      cam.celebrate(ball.position.clone());
      this.freeze = 2.5;
      ball.velocity.set(0, 0, 0);
      if (
        !this.training &&
        (this.scoreA >= MATCH_GOAL_LIMIT || this.scoreB >= MATCH_GOAL_LIMIT)
      ) {
        this.pendingEnd = 2.2;
      } else {
        this.pendingReset = 1.65;
        this.resetAttacker = g === 0 ? 1 : 0;
      }
    }
  }

  end(audio: AudioManager) {
    if (this.over) return;
    this.over = true;
    this.running = false;
    this.winner =
      this.scoreA === this.scoreB ? 2 : this.scoreA > this.scoreB ? 0 : 1;
    this.banner =
      this.winner === 2
        ? "مساوی"
        : this.winner === 0
          ? "پیروزی کوی ابوذر!"
          : "باخت...";
    this.bannerT = 5;
    audio.whistle();
  }
}
