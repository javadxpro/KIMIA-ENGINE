import type { BallEntity, Pitch, PlayerEntity } from "./types";
import { length2, norm2, clamp } from "./math";
import { RUN, SPRINT, WALK } from "./PlayerController";
import type { PlayerController } from "./PlayerController";

export class AIController {
  update(
    players: PlayerEntity[],
    ball: BallEntity,
    pitch: Pitch,
    dt: number,
    time: number,
    ctrl: PlayerController,
    enabled: boolean,
  ) {
    if (!enabled) {
      for (const p of players) {
        if (!p.isHuman) p.intended.set(0, 0, 0);
      }
      return;
    }
    const human = players.find((x) => x.isHuman) ?? null;
    for (const p of players) {
      if (p.isHuman) continue;
      if (p.stunTimer > 0 || p.actionLock > 0) {
        p.intended.set(0, 0, 0);
        continue;
      }
      p.aiThink -= dt;
      this.think(p, players, ball, pitch, dt, time, ctrl, human);
    }
  }

  private think(
    p: PlayerEntity,
    players: PlayerEntity[],
    ball: BallEntity,
    pitch: Pitch,
    dt: number,
    time: number,
    ctrl: PlayerController,
    human: PlayerEntity | null,
  ) {
    const attackX = p.team === 0 ? pitch.maxX : pitch.minX;
    const defendX = p.team === 0 ? pitch.minX : pitch.maxX;
    const toGoalX = attackX - p.position.x;
    const teamHas = players.some((x) => x.team === p.team && x.hasBall);
    const iHave = p.hasBall || ball.ownerId === p.id;
    const mates = players.filter((x) => x.team === p.team && x.id !== p.id);
    const foes = players.filter((x) => x.team !== p.team);

    const bx = ball.position.x;
    const bz = ball.position.z;
    const distBall = Math.hypot(bx - p.position.x, bz - p.position.z);

    let closestBall = true;
    for (const m of mates) {
      const md = Math.hypot(bx - m.position.x, bz - m.position.z);
      if (md + 0.35 < distBall) closestBall = false;
    }
    if (human && human.team === p.team && human.hasBall) closestBall = false;

    let tx = p.home.x;
    let tz = p.home.z;
    let spd = RUN * p.speedMul;
    p.aiState = "home";

    if (iHave) {
      p.aiState = "attack";
      const nearestFoe = foes.reduce((a, b) => {
        const da = Math.hypot(a.position.x - p.position.x, a.position.z - p.position.z);
        const db = Math.hypot(b.position.x - p.position.x, b.position.z - p.position.z);
        return db < da ? b : a;
      });
      const foeD = Math.hypot(
        nearestFoe.position.x - p.position.x,
        nearestFoe.position.z - p.position.z,
      );
      const goalDist = Math.abs(attackX - p.position.x);
      const facingGoal = p.team === 0 ? Math.sin(p.yaw) > 0.2 : Math.sin(p.yaw) < -0.2;

      const openMate = mates
        .map((m) => {
          const md = Math.hypot(m.position.x - p.position.x, m.position.z - p.position.z);
          const progress = p.team === 0 ? m.position.x - p.position.x : p.position.x - m.position.x;
          let marked = 0;
          for (const f of foes) {
            if (Math.hypot(f.position.x - m.position.x, f.position.z - m.position.z) < 2.4)
              marked++;
          }
          return { m, md, progress, marked };
        })
        .filter((x) => x.md > 2.4 && x.md < 12)
        .sort((a, b) => b.progress - a.marked * 3 - (a.progress - a.marked * 3))[0];

      if (goalDist < 8.5 && Math.abs(p.position.z) < 4.2 && facingGoal && time - p.lastKickAt > 1.2) {
        ctrl.startKick(p);
        p.lastKickAt = time;
        const dirX = attackX > p.position.x ? 1 : -1;
        const dirZ = clamp(-p.position.z * 0.08 + (Math.random() - 0.5) * 0.25, -0.45, 0.45);
        (p as PlayerEntity & { pendingKick?: { pwr: number; lift: number; x: number; z: number } }).pendingKick = {
          pwr: 0.55 + Math.random() * 0.35,
          lift: 0.15 + Math.random() * 0.45,
          x: dirX,
          z: dirZ,
        };
        tx = p.position.x + dirX;
        tz = p.position.z;
      } else if (foeD < 2.15 && openMate && time - p.lastPassAt > 1.1) {
        ctrl.startPass(p);
        p.lastPassAt = time;
        const dx = openMate.m.position.x - p.position.x;
        const dz = openMate.m.position.z - p.position.z;
        (p as PlayerEntity & { pendingPass?: { x: number; z: number; pwr: number } }).pendingPass = {
          x: dx,
          z: dz,
          pwr: clamp(openMate.md / 14, 0.28, 0.7),
        };
      } else {
        tx = attackX - Math.sign(attackX) * 2.8;
        tz = clamp(p.position.z * 0.4 + Math.sin(time * 1.3 + p.id) * 1.4, -5.5, 5.5);
        if (Math.abs(p.position.z) > 5.8) tz = p.position.z * 0.4;
        spd = (p.stamina > 0.3 ? SPRINT : RUN) * p.speedMul;
        p.stamina = clamp(p.stamina - dt * 0.12, 0.05, 1);
      }
    } else if (!teamHas && closestBall) {
      p.aiState = "chase";
      tx = bx;
      tz = bz;
      const ahead = 0.35;
      tx += ball.velocity.x * ahead;
      tz += ball.velocity.z * ahead;
      spd = (distBall > 4 ? SPRINT : RUN) * p.speedMul;
      if (
        distBall < 2.2 &&
        ball.ownerId >= 0 &&
        players.find((x) => x.id === ball.ownerId)?.team !== p.team &&
        time - p.lastTackleAt > 2.4 &&
        p.stamina > 0.25
      ) {
        const owner = players.find((x) => x.id === ball.ownerId);
        if (owner) {
          p.yaw = Math.atan2(owner.position.x - p.position.x, owner.position.z - p.position.z);
          ctrl.startTackle(p);
          p.lastTackleAt = time;
        }
      }
    } else if (teamHas) {
      p.aiState = "support";
      const owner = players.find((x) => x.id === ball.ownerId) ?? p;
      const side = p.role === "attack" ? 1 : p.role === "defend" ? -0.4 : 0.35;
      const spread = p.id % 2 === 0 ? 4.2 : -4.2;
      tx = owner.position.x + Math.sign(toGoalX || 1) * (4.5 * side + 2);
      tz = clamp(spread + owner.position.z * 0.2, -6.5, 6.5);
      if (human && human.team === p.team) {
        const hd = Math.hypot(human.position.x - tx, human.position.z - tz);
        if (hd < 2.4) {
          tx += 2.2;
          tz = tz > 0 ? tz + 1.5 : tz - 1.5;
        }
      }
      spd = RUN * 0.9 * p.speedMul;
      p.stamina = clamp(p.stamina + dt * 0.1, 0, 1);
    } else {
      p.aiState = "defend";
      const cover = 0.55;
      tx = defendX * (1 - cover) + bx * cover;
      if (p.team === 0) tx = Math.min(tx, -1.5);
      else tx = Math.max(tx, 1.5);
      tz = clamp(bz * 0.7 + (p.role === "defend" ? 0 : p.id % 2 === 0 ? 2.4 : -2.4), -6.2, 6.2);
      if (p.role === "defend") {
        tx = (defendX + bx) * 0.5;
        tz = clamp(bz * 0.85, -4.5, 4.5);
      }
      spd = (distBall < 8 ? RUN : WALK + 1) * p.speedMul;
    }

    tx = clamp(tx, pitch.minX - 1.6, pitch.maxX + 1.6);
    tz = clamp(tz, pitch.minZ + 0.6, pitch.maxZ - 0.6);

    const dx = tx - p.position.x;
    const dz = tz - p.position.z;
    const d = length2(dx, dz);
    if (d < 0.35) {
      p.intended.set(0, 0, 0);
    } else {
      const [nx, nz] = norm2(dx, dz);
      const slow = d < 1.2 ? 0.45 : 1;
      p.intended.set(nx * spd * slow, 0, nz * spd * slow);
    }
  }

  takePendingKick(p: PlayerEntity) {
    const ext = p as PlayerEntity & {
      pendingKick?: { pwr: number; lift: number; x: number; z: number };
      pendingPass?: { x: number; z: number; pwr: number };
    };
    if (ext.pendingKick && p.kickTimer > 0 && p.kickTimer < 0.18) {
      const k = ext.pendingKick;
      ext.pendingKick = undefined;
      return k;
    }
    if (ext.pendingPass && p.passTimer > 0 && p.passTimer < 0.14) {
      const k = ext.pendingPass;
      ext.pendingPass = undefined;
      return { pwr: k.pwr, lift: 0.05, x: k.x, z: k.z };
    }
    return null;
  }
}
