import type * as THREE from "three";
import type { PlayerEntity } from "./types";
import { spawnPlayer } from "./PlayerController";

export class TeamManager {
  players: PlayerEntity[] = [];

  spawn(scene: THREE.Scene) {
    this.players = [
      spawnPlayer(scene, {
        id: 0,
        team: 0,
        isHuman: true,
        name: "۱۰ ابوذر",
        number: 10,
        x: -3.2,
        z: 0.6,
        role: "attack",
      }),
      spawnPlayer(scene, {
        id: 1,
        team: 0,
        isHuman: false,
        name: "۷",
        number: 7,
        x: -7.4,
        z: -4.2,
        role: "mid",
      }),
      spawnPlayer(scene, {
        id: 2,
        team: 0,
        isHuman: false,
        name: "۴",
        number: 4,
        x: -10.5,
        z: 2.4,
        role: "defend",
      }),
      spawnPlayer(scene, {
        id: 3,
        team: 1,
        isHuman: false,
        name: "۹",
        number: 9,
        x: 3.2,
        z: -0.5,
        role: "attack",
      }),
      spawnPlayer(scene, {
        id: 4,
        team: 1,
        isHuman: false,
        name: "۸",
        number: 8,
        x: 7.2,
        z: 4.1,
        role: "mid",
      }),
      spawnPlayer(scene, {
        id: 5,
        team: 1,
        isHuman: false,
        name: "۵",
        number: 5,
        x: 10.6,
        z: -2.2,
        role: "defend",
      }),
    ];
    return this.players;
  }

  human() {
    return this.players[0];
  }

  resetKickoff(attackingTeam: 0 | 1 | null) {
    const spots: [number, number][][] = [
      [
        [-3.4, 0.8],
        [-7.5, -4.0],
        [-10.8, 2.6],
      ],
      [
        [3.4, -0.6],
        [7.4, 4.0],
        [10.8, -2.4],
      ],
    ];
    for (const p of this.players) {
      const i = this.players.filter((x) => x.team === p.team).indexOf(p);
      let [x, z] = spots[p.team][i];
      if (attackingTeam === p.team && i === 0) {
        x = p.team === 0 ? -1.2 : 1.2;
        z = 0.4;
      }
      p.position.set(x, 0, z);
      p.velocity.set(0, 0, 0);
      p.yaw = p.team === 0 ? Math.PI / 2 : -Math.PI / 2;
      p.hasBall = false;
      p.stunTimer = 0;
      p.kickTimer = 0;
      p.tackleTimer = 0;
      p.home.set(
        p.team === 0 ? -6 + i * 1.2 : 6 - i * 1.2,
        0,
        i === 0 ? 0 : i === 1 ? -4 : 3.5,
      );
      p.mesh.position.copy(p.position);
      p.mesh.rotation.y = p.yaw;
    }
  }

  setTraining() {
    for (const p of this.players) {
      if (p.isHuman) {
        p.position.set(-2, 0, 0);
        p.mesh.visible = true;
      } else if (p.team === 0) {
        p.position.set(4, 0, p.id === 1 ? -4.5 : 4.5);
        p.mesh.visible = true;
        p.intended.set(0, 0, 0);
      } else {
        p.mesh.visible = false;
        p.position.set(40, 0, 20 + p.id);
      }
      p.velocity.set(0, 0, 0);
      p.hasBall = false;
      p.mesh.position.copy(p.position);
    }
  }

  showAll() {
    for (const p of this.players) p.mesh.visible = true;
  }
}
