import * as THREE from "three";
import { clamp, damp } from "./math";
import type { PlayerEntity } from "./types";

export class CameraController {
  camera: THREE.PerspectiveCamera;
  yaw = 0.35;
  pitch = 0.38;
  dist = 6.4;
  private target = new THREE.Vector3();
  private pos = new THREE.Vector3();
  private look = new THREE.Vector3();
  private cinematicT = 0;
  mode: "follow" | "cinematic" | "goal" = "cinematic";
  private goalT = 0;
  private goalFocus = new THREE.Vector3();

  constructor(camera: THREE.PerspectiveCamera) {
    this.camera = camera;
  }

  addLook(dx: number, dy: number) {
    this.yaw -= dx;
    this.pitch = clamp(this.pitch + dy, 0.08, 1.15);
  }

  celebrate(pos: THREE.Vector3) {
    this.mode = "goal";
    this.goalT = 1.8;
    this.goalFocus.copy(pos);
  }

  update(
    dt: number,
    player: PlayerEntity | null,
    lookDx: number,
    lookDy: number,
  ) {
    if (this.mode === "cinematic") {
      this.cinematicT += dt * 0.12;
      const r = 22;
      const x = Math.cos(this.cinematicT) * r;
      const z = Math.sin(this.cinematicT) * r * 0.7;
      this.camera.position.set(x, 9.5, z + 4);
      this.camera.lookAt(0, 1.2, 0);
      return;
    }

    if (this.mode === "goal") {
      this.goalT -= dt;
      const t = this.cinematicT + (1.8 - this.goalT) * 0.5;
      this.camera.position.set(
        this.goalFocus.x + Math.cos(t) * 7,
        3.2,
        this.goalFocus.z + Math.sin(t) * 7,
      );
      this.camera.lookAt(this.goalFocus.x, 1.2, this.goalFocus.z);
      if (this.goalT <= 0) this.mode = "follow";
      return;
    }

    if (!player) return;
    this.addLook(lookDx, lookDy);

    const wantDist = player.anim === "sprint" ? 7.1 : 6.4;
    this.dist = damp(this.dist, wantDist, 3, dt);

    const offX = Math.sin(this.yaw) * Math.cos(this.pitch) * this.dist;
    const offY = Math.sin(this.pitch) * this.dist + 1.35;
    const offZ = Math.cos(this.yaw) * Math.cos(this.pitch) * this.dist;

    this.target.set(
      player.position.x,
      player.position.y + 1.25,
      player.position.z,
    );
    this.pos.set(
      this.target.x + offX,
      this.target.y + offY,
      this.target.z + offZ,
    );
    if (this.pos.y < 0.6) this.pos.y = 0.6;

    this.camera.position.x = damp(this.camera.position.x, this.pos.x, 8, dt);
    this.camera.position.y = damp(this.camera.position.y, this.pos.y, 8, dt);
    this.camera.position.z = damp(this.camera.position.z, this.pos.z, 8, dt);

    this.look.set(this.target.x, this.target.y + 0.35, this.target.z);
    this.camera.lookAt(this.look);
  }

  snapToPlayer(player: PlayerEntity) {
    this.mode = "follow";
    this.yaw = player.yaw + Math.PI;
    this.pitch = 0.38;
    const offX = Math.sin(this.yaw) * Math.cos(this.pitch) * this.dist;
    const offY = Math.sin(this.pitch) * this.dist + 1.35;
    const offZ = Math.cos(this.yaw) * Math.cos(this.pitch) * this.dist;
    this.camera.position.set(
      player.position.x + offX,
      player.position.y + 1.25 + offY,
      player.position.z + offZ,
    );
    this.camera.lookAt(
      player.position.x,
      player.position.y + 1.5,
      player.position.z,
    );
  }
}
