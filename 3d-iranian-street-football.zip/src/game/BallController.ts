import * as THREE from "three";
import type { BallEntity, PlayerEntity } from "./types";
import type { GameTextures } from "./textures";
import { createBallModel } from "./models";
import type { FootballPhysics } from "./FootballPhysics";
import type { AudioManager } from "./AudioManager";

export class BallController {
  ball: BallEntity;

  constructor(scene: THREE.Scene, tex: GameTextures) {
    const vis = createBallModel(tex.ball);
    scene.add(vis.group);
    this.ball = {
      position: new THREE.Vector3(0, 0.11, 0),
      velocity: new THREE.Vector3(),
      angular: new THREE.Vector3(),
      radius: 0.11,
      mesh: vis.group,
      spinMesh: vis.spin,
      ownerId: -1,
      lastOwnerId: -1,
      lastTouchAt: 10,
      onGround: true,
    };
  }

  reset(x = 0, z = 0) {
    this.ball.position.set(x, this.ball.radius + 0.02, z);
    this.ball.velocity.set(0, 0, 0);
    this.ball.angular.set(0, 0, 0);
    this.ball.ownerId = -1;
    this.ball.lastOwnerId = -1;
  }

  update(
    dt: number,
    players: PlayerEntity[],
    physics: FootballPhysics,
    audio: AudioManager,
  ) {
    const ball = this.ball;
    ball.lastTouchAt += dt;

    for (const p of players) p.hasBall = p.id === ball.ownerId;

    if (ball.ownerId >= 0) {
      const owner = players.find((p) => p.id === ball.ownerId);
      if (!owner || owner.stunTimer > 0) {
        ball.ownerId = -1;
      } else {
        const spd = Math.hypot(owner.velocity.x, owner.velocity.z);
        if (spd > 7.8 && Math.random() < dt * 0.35) {
          ball.ownerId = -1;
          ball.velocity.set(
            owner.velocity.x * 1.1,
            0.4,
            owner.velocity.z * 1.1,
          );
        } else {
          physics.dribble(owner, ball, dt);
        }
      }
    }

    if (ball.ownerId < 0) {
      const impact = physics.stepBall(ball, dt) ?? 0;
      if (impact > 3.2) audio.bounce(Math.min(1, impact / 12));
    }

    let best: PlayerEntity | null = null;
    let bestD = 99;
    for (const p of players) {
      if (physics.tryControl(p, ball)) {
        const d = Math.hypot(
          ball.position.x - p.position.x,
          ball.position.z - p.position.z,
        );
        const bias = p.isHuman ? -0.08 : 0;
        if (d + bias < bestD) {
          bestD = d + bias;
          best = p;
        }
      }
    }
    if (best && ball.ownerId !== best.id) {
      const owner = players.find((pl) => pl.id === ball.ownerId);
      const stealMate =
        owner?.isHuman && owner.team === best.team && !best.isHuman;
      if (!stealMate && (ball.ownerId < 0 || bestD < 0.62)) {
        ball.ownerId = best.id;
        best.hasBall = true;
        ball.lastOwnerId = best.id;
      }
    }

    for (const p of players) {
      if (p.tackleTimer > 0.1) {
        const dx = ball.position.x - p.position.x;
        const dz = ball.position.z - p.position.z;
        if (Math.hypot(dx, dz) < 0.95) {
          const fx = Math.sin(p.yaw);
          const fz = Math.cos(p.yaw);
          ball.ownerId = -1;
          ball.velocity.set(fx * 6.5, 1.4, fz * 6.5);
          ball.lastOwnerId = p.id;
          for (const o of players) {
            if (o.id !== p.id && o.team !== p.team) {
              const od = Math.hypot(
                o.position.x - p.position.x,
                o.position.z - p.position.z,
              );
              if (od < 1.15) {
                o.stunTimer = 0.7;
                o.hasBall = false;
                audio.tackle();
              }
            }
          }
        }
      }
    }

    ball.mesh.position.copy(ball.position);
    const blob = ball.mesh.children.find((c) => c !== ball.spinMesh);
    if (blob) {
      blob.position.y = -ball.position.y + 0.02;
      const s = 1 + ball.position.y * 0.4;
      blob.scale.set(s, s, 1);
      const mat = (blob as THREE.Mesh).material as THREE.MeshBasicMaterial;
      if (mat && "opacity" in mat) mat.opacity = 0.28 / (1 + ball.position.y);
    }
  }
}
