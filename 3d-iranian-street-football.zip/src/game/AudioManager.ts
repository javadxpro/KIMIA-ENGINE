export class AudioManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private ambient: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private started = false;
  sfx = true;
  music = true;
  private footAcc = 0;
  private musicOsc: OscillatorNode[] = [];

  async resume() {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.7;
      this.master.connect(this.ctx.destination);
      this.ambient = this.ctx.createGain();
      this.ambient.gain.value = 0.12;
      this.ambient.connect(this.master);
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.0;
      this.musicGain.connect(this.master);
    }
    if (this.ctx.state === "suspended") await this.ctx.resume();
    if (!this.started) {
      this.started = true;
      this.startAmbient();
      this.startMusic();
    }
  }

  setSfx(on: boolean) {
    this.sfx = on;
  }

  setMusic(on: boolean) {
    this.music = on;
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(
        on ? 0.09 : 0,
        this.ctx.currentTime,
        0.2,
      );
    }
  }

  private noise(duration: number) {
    if (!this.ctx) return null;
    const n = this.ctx.sampleRate * duration;
    const buf = this.ctx.createBuffer(1, n, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    return src;
  }

  private tone(
    freq: number,
    dur: number,
    type: OscillatorType,
    gain: number,
    freqEnd?: number,
  ) {
    if (!this.ctx || !this.master || !this.sfx) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    if (freqEnd)
      o.frequency.exponentialRampToValueAtTime(
        freqEnd,
        this.ctx.currentTime + dur,
      );
    g.gain.setValueAtTime(gain, this.ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + dur);
    o.connect(g);
    g.connect(this.master);
    o.start();
    o.stop(this.ctx.currentTime + dur + 0.02);
  }

  kick(power: number) {
    if (!this.ctx || !this.master || !this.sfx) return;
    this.tone(140 + power * 40, 0.12, "sine", 0.22 + power * 0.2, 50);
    const src = this.noise(0.12);
    if (!src) return;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 800 + power * 1200;
    const g = this.ctx.createGain();
    g.gain.value = 0.18 + power * 0.22;
    g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.12);
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start();
  }

  bounce(vol: number) {
    if (!this.sfx) return;
    this.tone(220, 0.07, "sine", 0.08 * vol, 90);
  }

  pass() {
    this.kick(0.25);
  }

  whistle() {
    if (!this.sfx) return;
    this.tone(1400, 0.35, "sine", 0.12, 1600);
    this.tone(1480, 0.28, "triangle", 0.05, 1700);
  }

  cheer() {
    if (!this.ctx || !this.master || !this.sfx) return;
    const src = this.noise(1.2);
    if (!src) return;
    const f = this.ctx.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = 900;
    f.Q.value = 0.7;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, this.ctx.currentTime);
    g.gain.linearRampToValueAtTime(0.16, this.ctx.currentTime + 0.15);
    g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 1.2);
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start();
  }

  tackle() {
    if (!this.sfx) return;
    this.tone(90, 0.16, "sawtooth", 0.1, 40);
    const src = this.noise(0.15);
    if (!src || !this.ctx || !this.master) return;
    const g = this.ctx.createGain();
    g.gain.value = 0.14;
    g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.15);
    src.connect(g);
    g.connect(this.master);
    src.start();
  }

  footstep(dt: number, speed: number) {
    if (!this.sfx || speed < 1.6) {
      this.footAcc = 0;
      return;
    }
    this.footAcc += dt * speed;
    if (this.footAcc > 1.15) {
      this.footAcc = 0;
      this.tone(70 + Math.random() * 30, 0.04, "sine", 0.035);
    }
  }

  private startAmbient() {
    if (!this.ctx || !this.ambient) return;
    const n = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, n, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * 0.4;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 500;
    src.connect(f);
    f.connect(this.ambient);
    src.start();

    const loopKids = () => {
      if (!this.ctx || !this.ambient || !this.sfx) {
        setTimeout(loopKids, 4000);
        return;
      }
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = "triangle";
      o.frequency.value = 420 + Math.random() * 280;
      g.gain.value = 0.012;
      g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.25);
      o.connect(g);
      g.connect(this.ambient);
      o.start();
      o.stop(this.ctx.currentTime + 0.28);
      setTimeout(loopKids, 2500 + Math.random() * 5000);
    };
    setTimeout(loopKids, 2000);

    const loopBike = () => {
      if (!this.ctx || !this.ambient) {
        setTimeout(loopBike, 8000);
        return;
      }
      if (this.sfx) {
        const o = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        o.type = "sawtooth";
        o.frequency.setValueAtTime(80, this.ctx.currentTime);
        o.frequency.linearRampToValueAtTime(140, this.ctx.currentTime + 1.4);
        o.frequency.linearRampToValueAtTime(70, this.ctx.currentTime + 2.6);
        g.gain.setValueAtTime(0.0001, this.ctx.currentTime);
        g.gain.linearRampToValueAtTime(0.03, this.ctx.currentTime + 0.4);
        g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 2.6);
        o.connect(g);
        g.connect(this.ambient);
        o.start();
        o.stop(this.ctx.currentTime + 2.7);
      }
      setTimeout(loopBike, 9000 + Math.random() * 10000);
    };
    setTimeout(loopBike, 5000);
  }

  private startMusic() {
    if (!this.ctx || !this.musicGain) return;
    const notes = [196, 233, 261, 293, 311, 349];
    const make = (freq: number, type: OscillatorType, gain: number) => {
      const o = this.ctx!.createOscillator();
      const g = this.ctx!.createGain();
      o.type = type;
      o.frequency.value = freq;
      g.gain.value = gain;
      o.connect(g);
      g.connect(this.musicGain!);
      o.start();
      this.musicOsc.push(o);
      return o;
    };
    make(notes[0] / 2, "sine", 0.35);
    make(notes[2], "triangle", 0.12);
    make(notes[4], "sine", 0.08);
    this.musicGain.gain.value = this.music ? 0.09 : 0;

    let i = 0;
    const step = () => {
      if (!this.ctx) return;
      const o = this.musicOsc[1];
      if (o) {
        const f = notes[i % notes.length];
        o.frequency.setTargetAtTime(f, this.ctx.currentTime, 0.15);
      }
      i++;
      setTimeout(step, 1400);
    };
    step();
  }

  dispose() {
    void this.ctx?.close();
    this.ctx = null;
  }
}
