import type * as THREE from "three";

export type Quality = "low" | "medium" | "high";
export type GameMode = "menu" | "playing" | "training" | "paused" | "result";
export type AnimState =
  | "idle"
  | "walk"
  | "run"
  | "sprint"
  | "kick"
  | "pass"
  | "tackle"
  | "stun";

export interface GameSettings {
  quality: Quality;
  sfx: boolean;
  music: boolean;
  sensitivity: number;
}

export interface Collider {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
  bounce: number;
  kind: "building" | "fence" | "prop" | "low";
}

export interface Pitch {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  goalWidth: number;
  goalHeight: number;
  goalDepth: number;
}

export interface PlayerBones {
  root: THREE.Group;
  torso: THREE.Object3D;
  head: THREE.Object3D;
  lArm: THREE.Object3D;
  rArm: THREE.Object3D;
  lFore: THREE.Object3D;
  rFore: THREE.Object3D;
  lThigh: THREE.Object3D;
  rThigh: THREE.Object3D;
  lShin: THREE.Object3D;
  rShin: THREE.Object3D;
}

export interface PlayerEntity {
  id: number;
  team: 0 | 1;
  isHuman: boolean;
  name: string;
  number: number;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  yaw: number;
  radius: number;
  height: number;
  mesh: THREE.Group;
  bones: PlayerBones;
  anim: AnimState;
  animPhase: number;
  kickTimer: number;
  passTimer: number;
  tackleTimer: number;
  stunTimer: number;
  actionLock: number;
  hasBall: boolean;
  stamina: number;
  home: THREE.Vector3;
  role: "attack" | "mid" | "defend";
  skin: number;
  intended: THREE.Vector3;
  speedMul: number;
  lastKickAt: number;
  lastPassAt: number;
  lastTackleAt: number;
  aiThink: number;
  aiState: string;
  controlStick: number;
}

export interface BallEntity {
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  angular: THREE.Vector3;
  radius: number;
  mesh: THREE.Group;
  spinMesh: THREE.Object3D;
  ownerId: number;
  lastOwnerId: number;
  lastTouchAt: number;
  onGround: boolean;
}

export interface NpcEntity {
  mesh: THREE.Group;
  bones: PlayerBones;
  path: THREE.Vector3[];
  seg: number;
  t: number;
  speed: number;
  yaw: number;
  phase: number;
  kind: "walker" | "kid" | "spectator" | "shopkeeper";
}

export interface UIState {
  mode: GameMode;
  scoreA: number;
  scoreB: number;
  timeLeft: number;
  shotPower: number;
  charging: boolean;
  message: string;
  banner: string;
  teamA: string;
  teamB: string;
  showMobile: boolean;
  quality: Quality;
  sfx: boolean;
  music: boolean;
  sensitivity: number;
  trainingTips: boolean;
  matchOver: boolean;
  winner: 0 | 1 | 2;
  paused: boolean;
  goalsA: number;
  goalsB: number;
}

export const TEAM_A_NAME = "کوی ابوذر";
export const TEAM_B_NAME = "بچه‌های نبرد";

export const MATCH_SECONDS = 180;
export const MATCH_GOAL_LIMIT = 5;

export const initialUI = (): UIState => ({
  mode: "menu",
  scoreA: 0,
  scoreB: 0,
  timeLeft: MATCH_SECONDS,
  shotPower: 0,
  charging: false,
  message: "",
  banner: "",
  teamA: TEAM_A_NAME,
  teamB: TEAM_B_NAME,
  showMobile: false,
  quality: "medium",
  sfx: true,
  music: true,
  sensitivity: 1,
  trainingTips: false,
  matchOver: false,
  winner: 2,
  paused: false,
  goalsA: 0,
  goalsB: 0,
});
