import * as THREE from "three";

function canvasTex(
  size: number,
  draw: (ctx: CanvasRenderingContext2D, size: number) => void,
  repeat = 4,
) {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d")!;
  draw(ctx, size);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  tex.needsUpdate = true;
  return tex;
}

export interface GameTextures {
  brick: THREE.CanvasTexture;
  plaster: THREE.CanvasTexture;
  plasterDark: THREE.CanvasTexture;
  asphalt: THREE.CanvasTexture;
  sidewalk: THREE.CanvasTexture;
  metal: THREE.CanvasTexture;
  wood: THREE.CanvasTexture;
  ball: THREE.CanvasTexture;
  windowLit: THREE.CanvasTexture;
  windowDark: THREE.CanvasTexture;
  rug: THREE.CanvasTexture;
  net: THREE.CanvasTexture;
  rust: THREE.CanvasTexture;
  dirt: THREE.CanvasTexture;
  foliage: THREE.CanvasTexture;
}

export function makeSignTexture(
  text: string,
  bg: string,
  fg: string,
  w = 512,
  h = 220,
) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "rgba(0,0,0,0.12)";
  for (let i = 0; i < 40; i++) {
    ctx.fillRect(Math.random() * w, Math.random() * h, 8, 2);
  }
  ctx.strokeStyle = "rgba(0,0,0,0.35)";
  ctx.lineWidth = 10;
  ctx.strokeRect(8, 8, w - 16, h - 16);
  ctx.fillStyle = fg;
  ctx.font = `700 ${Math.floor(h * 0.38)}px Vazirmatn, Tahoma, sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.direction = "rtl";
  ctx.fillText(text, w / 2, h / 2 + 4);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createTextures(): GameTextures {
  const brick = canvasTex(256, (ctx, s) => {
    ctx.fillStyle = "#6e3b2e";
    ctx.fillRect(0, 0, s, s);
    const bw = 32;
    const bh = 14;
    for (let y = 0, row = 0; y < s; y += bh, row++) {
      const off = row % 2 === 0 ? 0 : bw / 2;
      for (let x = -bw; x < s; x += bw) {
        const n = (Math.sin(x * 12.3 + y * 7.1) * 0.5 + 0.5) * 30;
        ctx.fillStyle = `rgb(${120 + n},${58 + n * 0.4},${42 + n * 0.2})`;
        ctx.fillRect(x + off + 1, y + 1, bw - 2, bh - 2);
        ctx.fillStyle = "rgba(255,220,180,0.07)";
        ctx.fillRect(x + off + 2, y + 2, bw - 6, 3);
      }
    }
  }, 3);

  const plaster = canvasTex(256, (ctx, s) => {
    ctx.fillStyle = "#cbb396";
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 1800; i++) {
      const v = 160 + Math.random() * 50;
      ctx.fillStyle = `rgba(${v},${v - 20},${v - 40},${0.15 + Math.random() * 0.2})`;
      ctx.fillRect(Math.random() * s, Math.random() * s, 3, 3);
    }
    ctx.strokeStyle = "rgba(90,70,50,0.12)";
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      ctx.moveTo(Math.random() * s, 0);
      ctx.lineTo(Math.random() * s, s);
    }
    ctx.stroke();
  }, 2);

  const plasterDark = canvasTex(256, (ctx, s) => {
    ctx.fillStyle = "#8a7358";
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 1200; i++) {
      ctx.fillStyle = `rgba(40,30,20,${Math.random() * 0.18})`;
      ctx.fillRect(Math.random() * s, Math.random() * s, 4, 3);
    }
  }, 2);

  const asphalt = canvasTex(512, (ctx, s) => {
    ctx.fillStyle = "#3a3a3a";
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 8000; i++) {
      const g = 40 + Math.random() * 40;
      ctx.fillStyle = `rgb(${g},${g},${g - 2})`;
      ctx.fillRect(Math.random() * s, Math.random() * s, 2, 2);
    }
    ctx.strokeStyle = "rgba(20,20,20,0.55)";
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 18; i++) {
      ctx.beginPath();
      let x = Math.random() * s;
      let y = Math.random() * s;
      ctx.moveTo(x, y);
      for (let k = 0; k < 6; k++) {
        x += (Math.random() - 0.45) * 50;
        y += (Math.random() - 0.3) * 40;
        ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(90,80,60,0.12)";
    ctx.fillRect(0, 0, s, s);
  }, 6);

  const sidewalk = canvasTex(256, (ctx, s) => {
    ctx.fillStyle = "#9a948a";
    ctx.fillRect(0, 0, s, s);
    const t = 64;
    for (let y = 0; y < s; y += t) {
      for (let x = 0; x < s; x += t) {
        const n = Math.random() * 18;
        ctx.fillStyle = `rgb(${150 + n},${144 + n},${132 + n})`;
        ctx.fillRect(x + 1, y + 1, t - 2, t - 2);
        ctx.strokeStyle = "rgba(70,65,55,0.35)";
        ctx.strokeRect(x + 0.5, y + 0.5, t, t);
      }
    }
  }, 8);

  const metal = canvasTex(128, (ctx, s) => {
    const g = ctx.createLinearGradient(0, 0, s, s);
    g.addColorStop(0, "#6a7074");
    g.addColorStop(0.5, "#9aa0a4");
    g.addColorStop(1, "#5c6166");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = "rgba(255,255,255,0.08)";
    for (let y = 0; y < s; y += 4) ctx.fillRect(0, y, s, 1);
  }, 2);

  const wood = canvasTex(128, (ctx, s) => {
    ctx.fillStyle = "#6b4423";
    ctx.fillRect(0, 0, s, s);
    for (let x = 0; x < s; x += 6) {
      ctx.fillStyle = `rgba(${80 + Math.random() * 40},${50},${20},${0.3})`;
      ctx.fillRect(x, 0, 4, s);
    }
  }, 2);

  const ball = canvasTex(256, (ctx, s) => {
    ctx.fillStyle = "#f2f2f2";
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = "#161616";
    const hex = (cx: number, cy: number, r: number) => {
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = (Math.PI / 3) * i + 0.3;
        const x = cx + Math.cos(a) * r;
        const y = cy + Math.sin(a) * r;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
    };
    hex(s * 0.5, s * 0.5, 28);
    hex(s * 0.18, s * 0.22, 22);
    hex(s * 0.82, s * 0.28, 22);
    hex(s * 0.2, s * 0.78, 22);
    hex(s * 0.78, s * 0.76, 22);
    ctx.strokeStyle = "#222";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(s / 2, s / 2, s * 0.46, 0, Math.PI * 2);
    ctx.stroke();
  }, 1);
  ball.wrapS = ball.wrapT = THREE.ClampToEdgeWrapping;

  const windowLit = canvasTex(64, (ctx, s) => {
    ctx.fillStyle = "#3a2a18";
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = "#f0c060";
    ctx.fillRect(4, 4, s - 8, s - 8);
    ctx.fillStyle = "rgba(255,230,140,0.5)";
    ctx.fillRect(6, 6, s * 0.4, s * 0.35);
    ctx.strokeStyle = "#2a1c10";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(s / 2, 4);
    ctx.lineTo(s / 2, s - 4);
    ctx.moveTo(4, s / 2);
    ctx.lineTo(s - 4, s / 2);
    ctx.stroke();
  }, 1);

  const windowDark = canvasTex(64, (ctx, s) => {
    ctx.fillStyle = "#2c241c";
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = "#1a2230";
    ctx.fillRect(4, 4, s - 8, s - 8);
    ctx.fillStyle = "rgba(180,200,220,0.08)";
    ctx.fillRect(6, 6, s * 0.35, s * 0.3);
    ctx.strokeStyle = "#3a3028";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(s / 2, 4);
    ctx.lineTo(s / 2, s - 4);
    ctx.moveTo(4, s / 2);
    ctx.lineTo(s - 4, s / 2);
    ctx.stroke();
  }, 1);

  const rug = canvasTex(128, (ctx, s) => {
    ctx.fillStyle = "#6b1d1d";
    ctx.fillRect(0, 0, s, s);
    ctx.strokeStyle = "#d4b24a";
    ctx.lineWidth = 8;
    ctx.strokeRect(8, 8, s - 16, s - 16);
    ctx.fillStyle = "#1e4d3a";
    ctx.fillRect(24, 24, s - 48, s - 48);
    ctx.fillStyle = "#d4b24a";
    ctx.beginPath();
    ctx.arc(s / 2, s / 2, 14, 0, Math.PI * 2);
    ctx.fill();
  }, 1);

  const net = canvasTex(64, (ctx, s) => {
    ctx.clearRect(0, 0, s, s);
    ctx.strokeStyle = "rgba(230,230,230,0.7)";
    ctx.lineWidth = 2;
    for (let i = 0; i <= s; i += 8) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, s);
      ctx.moveTo(0, i);
      ctx.lineTo(s, i);
      ctx.stroke();
    }
  }, 6);
  net.premultiplyAlpha = true;

  const rust = canvasTex(128, (ctx, s) => {
    ctx.fillStyle = "#5a4638";
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 400; i++) {
      ctx.fillStyle = `rgba(${90 + Math.random() * 80},${40 + Math.random() * 30},20,0.4)`;
      ctx.beginPath();
      ctx.arc(Math.random() * s, Math.random() * s, Math.random() * 6, 0, 7);
      ctx.fill();
    }
  }, 2);

  const dirt = canvasTex(128, (ctx, s) => {
    ctx.fillStyle = "#6a5a40";
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 600; i++) {
      const g = 70 + Math.random() * 40;
      ctx.fillStyle = `rgb(${g},${g - 15},${g - 35})`;
      ctx.fillRect(Math.random() * s, Math.random() * s, 3, 3);
    }
  }, 4);

  const foliage = canvasTex(64, (ctx, s) => {
    ctx.fillStyle = "#2f4a28";
    ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 80; i++) {
      ctx.fillStyle = `rgba(${30 + Math.random() * 40},${80 + Math.random() * 70},30,0.5)`;
      ctx.beginPath();
      ctx.arc(Math.random() * s, Math.random() * s, 6, 0, 7);
      ctx.fill();
    }
  }, 1);

  return {
    brick,
    plaster,
    plasterDark,
    asphalt,
    sidewalk,
    metal,
    wood,
    ball,
    windowLit,
    windowDark,
    rug,
    net,
    rust,
    dirt,
    foliage,
  };
}
