import * as THREE from "three";
import { animatePlayer, createPlayerModel } from "./models";
import { angleDamp, clamp, length2 } from "./math";
import type { AnimState, PlayerEntity } from "./types";
import type { InputManager } from "./InputManager";
import type { CameraController } from "./CameraController";
import type { FootballPhysics } from "./FootballPhysics";

const WALK = 3.4;
const RUN = 6.35;
const SPRINT = 8.4;

export const TEAM_A_KIT = {
  jersey: 0x1f6b3a,
  stripe: 0xf2f2f2,
  shorts: 0xf3f3f3,
  socks: 0x1f6b3a,
};
export const TEAM_B_KIT = {
  jersey: 0x8a1e1e,
  stripe: 0xe8d48a,
  shorts: 0x1a1a1a,
  socks: 0x8a1e1e,
};

const SKINS = [0xc49a72, 0xb8885a, 0xd4ae86, 0xa87848, 0xc9a07a];
const HAIRS = [0x1a120c, 0x2a1a10, 0x111111, 0x3a2818];

export function spawnPlayer(
  scene: THREE.Scene,
  opts: {
    id: number;
    team: 0 | 1;
    isHuman: boolean;
    name: string;
    number: number;
    x: number;
    z: number;
    role: PlayerEntity["role"];
  },
): PlayerEntity {
  const kit = opts.team === 0 ? TEAM_A_KIT : TEAM_B_KIT;
  const vis = createPlayerModel({
    skin: SKINS[opts.id % SKINS.length],
    hair: HAIRS[opts.id % HAIRS.length],
    jersey: kit.jersey,
    stripe: kit.stripe,
    shorts: kit.shorts,
    socks: kit.socks,
    shoes: 0x1a1a1a,
    number: opts.number,
  });
  vis.group.position.set(opts.x, 0, opts.z);
  scene.add(vis.group);
  return {
    id: opts.id,
    team: opts.team,
    isHuman: opts.isHuman,
    name: opts.name,
    number: opts.number,
    position: new THREE.Vector3(opts.x, 0, opts.z),
    velocity: new THREE.Vector3(),
    yaw: opts.team === 0 ? Math.PI / 2 : -Math.PI / 2,
    radius: 0.34,
    height: 1.75,
    mesh: vis.group,
    bones: vis.bones,
    anim: "idle",
    animPhase: Math.random() * 10,
    kickTimer: 0,
    passTimer: 0,
    tackleTimer: 0,
    stunTimer: 0,
    actionLock: 0,
    hasBall: false,
    stamina: 1,
    home: new THREE.Vector3(opts.x, 0, opts.z),
    role: opts.role,
    skin: SKINS[opts.id % SKINS.length],
    intended: new THREE.Vector3(),
    speedMul: opts.isHuman ? 1.04 : 0.92 + Math.random() * 0.1,
    lastKickAt: -10,
    lastPassAt: -10,
    lastTackleAt: -10,
    aiThink: 0,
    aiState: "idle",
    controlStick: 0,
  };
}

export class PlayerController {
  charge = 0;
  charging = false;
  private lastShootHeld = false;

  updateHuman(
    p: PlayerEntity,
    input: InputManager,
    cam: CameraController,
    dt: number,
  ) {
    if (p.stunTimer > 0 || p.actionLock > 0) {
      p.intended.set(0, 0, 0);
      if (input.shootHeld) {
        this.charging = true;
        this.charge = clamp(this.charge + dt * 1.15, 0, 1);
      }
      return;
    }
    const mv = input.getMove();
    const camYaw = cam.yaw;
    const fwdX = -Math.sin(camYaw);
    const fwdZ = -Math.cos(camYaw);
    const rightX = Math.cos(camYaw);
    const rightZ = -Math.sin(camYaw);
    const fx = rightX * mv.x + fwdX * -mv.z;
    const fz = rightZ * mv.x + fwdZ * -mv.z;
    const mag = Math.min(1, Math.hypot(fx, fz));
    p.intended.set(fx, 0, fz);
    if (mag > 0.08) {
      const [nx, nz] = [fx / mag, fz / mag];
      p.intended.set(nx * mag, 0, nz * mag);
    } else p.intended.set(0, 0, 0);

    const sprint = input.sprintHeld && p.stamina > 0.08 && mag > 0.2;
    if (sprint) p.stamina = clamp(p.stamina - dt * 0.22, 0, 1);
    else p.stamina = clamp(p.stamina + dt * 0.16, 0, 1);

    const spd =
      mag < 0.01
        ? 0
        : sprint
          ? SPRINT
          : mag > 0.55
            ? RUN
            : WALK;
    p.intended.multiplyScalar(spd * p.speedMul);

    if (input.shootHeld) {
      this.charging = true;
      this.charge = clamp(this.charge + dt * 1.15, 0, 1);
    } else if (this.lastShootHeld && this.charging) {
      this.charging = false;
    }
    this.lastShootHeld = input.shootHeld;
  }

  consumeShot(): number | null {
    if (this.lastShootHeld || this.charging) return null;
    if (this.charge > 0) {
      const pwr = this.charge;
      this.charge = 0;
      return pwr;
    }
    return null;
  }

  tickMotion(p: PlayerEntity, dt: number, physics: FootballPhysics) {
    p.kickTimer = Math.max(0, p.kickTimer - dt);
    p.passTimer = Math.max(0, p.passTimer - dt);
    p.tackleTimer = Math.max(0, p.tackleTimer - dt);
    p.stunTimer = Math.max(0, p.stunTimer - dt);
    p.actionLock = Math.max(0, p.actionLock - dt);

    if (p.stunTimer > 0) {
      p.velocity.multiplyScalar(Math.exp(-8 * dt));
    } else if (p.tackleTimer > 0.05) {
      const dash = 11;
      p.velocity.x = Math.sin(p.yaw) * dash;
      p.velocity.z = Math.cos(p.yaw) * dash;
    } else {
      const ax = p.intended.x;
      const az = p.intended.z;
      p.velocity.x += (ax - p.velocity.x) * Math.min(1, dt * 9);
      p.velocity.z += (az - p.velocity.z) * Math.min(1, dt * 9);
    }

    physics.collidePlayerWorld(p, dt);

    const spd = length2(p.velocity.x, p.velocity.z);
    if (spd > 0.45 && p.stunTimer <= 0) {
      p.yaw = angleDamp(p.yaw, Math.atan2(p.velocity.x, p.velocity.z), 12, dt);
    }

    p.mesh.position.copy(p.position);
    p.mesh.rotation.y = p.yaw;

    let anim: AnimState = "idle";
    if (p.stunTimer > 0) anim = "stun";
    else if (p.kickTimer > 0) anim = "kick";
    else if (p.passTimer > 0) anim = "pass";
    else if (p.tackleTimer > 0) anim = "tackle";
    else if (spd > 7.2) anim = "sprint";
    else if (spd > 4.4) anim = "run";
    else if (spd > 0.5) anim = "walk";
    p.anim = anim;
    const freq = anim === "sprint" ? 11 : anim === "run" ? 8.5 : anim === "walk" ? 6 : 2.2;
    p.animPhase += dt * freq;
    animatePlayer(
      p.bones,
      anim,
      p.animPhase,
      spd,
      p.kickTimer,
      p.tackleTimer,
    );
  }

  startKick(p: PlayerEntity) {
    p.kickTimer = 0.32;
    p.actionLock = 0.28;
    p.lastKickAt = 0;
  }

  startPass(p: PlayerEntity) {
    p.passTimer = 0.24;
    p.actionLock = 0.2;
    p.lastPassAt = 0;
  }

  startTackle(p: PlayerEntity) {
    if (p.stamina < 0.15) return false;
    p.tackleTimer = 0.38;
    p.actionLock = 0.4;
    p.stamina -= 0.18;
    p.lastTackleAt = 0;
    return true;
  }
}

export { WALK, RUN, SPRINT };
