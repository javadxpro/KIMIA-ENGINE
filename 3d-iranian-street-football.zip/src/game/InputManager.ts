export class InputManager {
  keys = new Set<string>();
  mouseDx = 0;
  mouseDy = 0;
  lookX = 0;
  lookY = 0;
  joyX = 0;
  joyY = 0;
  shootHeld = false;
  shootPressed = false;
  passPressed = false;
  tacklePressed = false;
  sprintHeld = false;
  resetPressed = false;
  pausePressed = false;
  pointerLocked = false;
  usingTouch = false;
  sensitivity = 1;

  private mobileShoot = false;
  private mobileSprint = false;
  private mobilePass = false;
  private mobileTackle = false;
  private shootWas = false;
  private passWas = false;
  private tackleWas = false;
  private dragging = false;
  private canvas: HTMLCanvasElement;
  private onMove: (e: MouseEvent) => void;
  private onDown: (e: MouseEvent) => void;
  private onUp: (e: MouseEvent) => void;
  private onKeyDown: (e: KeyboardEvent) => void;
  private onKeyUp: (e: KeyboardEvent) => void;
  private onTouchStart: (e: TouchEvent) => void;
  private onTouchMove: (e: TouchEvent) => void;
  private onTouchEnd: (e: TouchEvent) => void;
  private lookId: number | null = null;
  private lastLookX = 0;
  private lastLookY = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.onMove = (e) => {
      if (this.pointerLocked || this.dragging) {
        this.mouseDx += e.movementX;
        this.mouseDy += e.movementY;
      }
    };
    this.onDown = (e) => {
      if (e.button === 2) e.preventDefault();
      if (!this.usingTouch && (e.button === 0 || e.button === 2)) {
        this.dragging = true;
        void this.canvas.requestPointerLock();
      }
    };
    this.onUp = () => {
      this.dragging = false;
    };
    this.onKeyDown = (e) => {
      this.keys.add(e.code);
      if (e.code === "Escape") this.pausePressed = true;
      if (e.code === "KeyR") this.resetPressed = true;
      if (["Space", "KeyE", "KeyQ"].includes(e.code)) e.preventDefault();
    };
    this.onKeyUp = (e) => this.keys.delete(e.code);
    this.onTouchStart = (e) => {
      this.usingTouch = true;
      for (const t of Array.from(e.changedTouches)) {
        if (t.clientX > window.innerWidth * 0.42 && this.lookId === null) {
          const el = document.elementFromPoint(t.clientX, t.clientY) as HTMLElement | null;
          if (el?.dataset?.ui === "btn") continue;
          this.lookId = t.identifier;
          this.lastLookX = t.clientX;
          this.lastLookY = t.clientY;
        }
      }
    };
    this.onTouchMove = (e) => {
      e.preventDefault();
      for (const t of Array.from(e.touches)) {
        if (t.identifier === this.lookId) {
          this.mouseDx += (t.clientX - this.lastLookX) * 1.6;
          this.mouseDy += (t.clientY - this.lastLookY) * 1.6;
          this.lastLookX = t.clientX;
          this.lastLookY = t.clientY;
        }
      }
    };
    this.onTouchEnd = (e) => {
      for (const t of Array.from(e.changedTouches)) {
        if (t.identifier === this.lookId) this.lookId = null;
      }
    };

    window.addEventListener("mousemove", this.onMove);
    canvas.addEventListener("mousedown", this.onDown);
    window.addEventListener("mouseup", this.onUp);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    canvas.addEventListener("touchstart", this.onTouchStart, { passive: true });
    canvas.addEventListener("touchmove", this.onTouchMove, { passive: false });
    canvas.addEventListener("touchend", this.onTouchEnd);
    canvas.addEventListener("contextmenu", (e) => e.preventDefault());
    document.addEventListener("pointerlockchange", this.onLock);
  }

  private onLock = () => {
    this.pointerLocked = document.pointerLockElement === this.canvas;
  };

  setJoystick(x: number, y: number) {
    this.joyX = x;
    this.joyY = y;
    this.usingTouch = true;
  }

  setAction(
    action: "shoot" | "pass" | "tackle" | "sprint" | "reset",
    down: boolean,
  ) {
    this.usingTouch = true;
    if (action === "shoot") this.mobileShoot = down;
    if (action === "pass") this.mobilePass = down;
    if (action === "tackle") this.mobileTackle = down;
    if (action === "sprint") this.mobileSprint = down;
    if (action === "reset") this.resetPressed = down;
  }

  preUpdate() {
    const kbShoot = this.keys.has("Space");
    const kbPass = this.keys.has("KeyE");
    const kbTackle = this.keys.has("KeyQ");
    this.shootHeld = kbShoot || this.mobileShoot;
    this.shootPressed = this.shootHeld && !this.shootWas;
    const passDown = kbPass || this.mobilePass;
    const tackleDown = kbTackle || this.mobileTackle;
    this.passPressed = passDown && !this.passWas;
    this.tacklePressed = tackleDown && !this.tackleWas;
    this.shootWas = this.shootHeld;
    this.passWas = passDown;
    this.tackleWas = tackleDown;
    this.sprintHeld =
      this.mobileSprint || this.keys.has("ShiftLeft") || this.keys.has("ShiftRight");

    this.lookX = this.mouseDx * 0.0045 * this.sensitivity;
    this.lookY = this.mouseDy * 0.0045 * this.sensitivity;
    this.mouseDx = 0;
    this.mouseDy = 0;
  }

  getMove(): { x: number; z: number } {
    let x = 0;
    let z = 0;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) z -= 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) z += 1;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) x -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) x += 1;
    if (Math.abs(this.joyX) > 0.08 || Math.abs(this.joyY) > 0.08) {
      x += this.joyX;
      z += this.joyY;
    }
    const l = Math.hypot(x, z);
    if (l > 1) {
      x /= l;
      z /= l;
    }
    return { x, z };
  }

  postUpdate() {
    this.resetPressed = false;
    this.pausePressed = false;
  }

  dispose() {
    window.removeEventListener("mousemove", this.onMove);
    this.canvas.removeEventListener("mousedown", this.onDown);
    window.removeEventListener("mouseup", this.onUp);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    this.canvas.removeEventListener("touchstart", this.onTouchStart);
    this.canvas.removeEventListener("touchmove", this.onTouchMove);
    this.canvas.removeEventListener("touchend", this.onTouchEnd);
    document.removeEventListener("pointerlockchange", this.onLock);
  }
}
